from setuptools import setup, find_packages

setup(
    name='pseudo_rgbd_slam',
    version='1.0.0',
    packages=find_packages(),
    install_requires=['setuptools'],
)
