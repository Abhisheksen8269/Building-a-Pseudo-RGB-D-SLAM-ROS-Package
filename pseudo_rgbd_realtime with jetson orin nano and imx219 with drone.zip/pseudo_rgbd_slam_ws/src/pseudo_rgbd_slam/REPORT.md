# Pseudo RGB-D SLAM — Technical Report

## 1. Problem Statement

Build a modular ROS 2 pipeline that performs RGB-D SLAM **without a physical depth sensor**,
replacing it with a monocular metric depth estimation network (Depth Anything V2).

---

## 2. System Overview

Three ROS 2 nodes communicate via topics:

| Node | Role | Key Output Topics |
|---|---|---|
| A — Broadcaster | Captures RGB from IMX219 (GStreamer) or TUM dataset | `/camera/image_raw` |
| B — Depth Estimator | Runs Depth Anything V2 Small (metric, indoor) | `/depth/image_raw`, `/depth/image_visual` |
| C — Pseudo SLAM | ORB-SLAM2 RGB-D mode, fuses RGB + predicted depth | `/slam/pose`, `/slam/trajectory`, `/slam/map_points` |

---

## 3. Mathematical Derivation

### 3.1 Pinhole Camera Model

Given intrinsics **K** = [fx, 0, cx; 0, fy, cy; 0, 0, 1], a pixel (u,v) with depth Z(u,v)
back-projects to 3-D as:

```
P = Z(u,v) · K⁻¹ · [u, v, 1]ᵀ
  = [ (u - cx)·Z/fx,  (v - cy)·Z/fy,  Z ]ᵀ
```

For TUM fr1/desk (640×480): fx=517.3, fy=516.5, cx=318.6, cy=255.3.
Scaled to 960×540: fx=775.95, fy=581.06, cx=477.9, cy=287.2.

### 3.2 Depth Anything V2 — Architecture

Depth Anything V2 uses a **DPT (Dense Prediction Transformer)** head on a
**ViT-Small** backbone:

```
RGB image (H×W×3)
  → patch embedding (14×14 patches) → [N_patches, d=384] tokens
  → 12 × Transformer layers (self-attention + FFN)
  → DPT decoder: reassembles tokens → 4 feature maps
  → Fusion + convolutional head
  → Metric depth map D(u,v) ∈ ℝ⁺  [metres]
```

The metric variant appends a **scale+shift calibration** learned from mixed datasets
with absolute depth labels, so D(u,v) is in metres with no post-hoc scale factor.

**Loss function** (metric variant):
```
L = λ_affine · L_si  +  λ_grad · L_grad  +  λ_normal · L_normal
```
where L_si is scale-invariant log loss, L_grad is multi-scale gradient loss,
and L_normal is surface-normal consistency.

### 3.3 ORB Feature Extraction

For each image I, ORB features are extracted at N levels of an image pyramid (scale
factor s=1.2). At each level:

1. **FAST corners** (threshold=20, adaptive min=7)
2. **Harris score** for retention (top n_features per level)
3. **Orientation** via intensity centroid:
   m₁₀ = Σ x·I(x,y),  m₀₁ = Σ y·I(x,y)
   θ = atan2(m₀₁, m₁₀)
4. **BRIEF descriptor** steered by θ → 256-bit binary descriptor

### 3.4 RGB-D Tracking (PnP + RANSAC)

Given current frame features {(uᵢ, vᵢ, dᵢ)} and previous keyframe map points {Pⱼ}:

1. **Descriptor matching** via Hamming distance + ratio test
2. **3-D back-projection**: Pᵢ = back_project(uᵢ, vᵢ, D(uᵢ,vᵢ))
3. **PnP pose estimation**: minimize reprojection error over pose T ∈ SE(3):

```
T* = argmin_T  Σᵢ  ‖πK(T·Pᵢ) − (uᵢ, vᵢ)‖²
```

where πK(·) is the perspective projection.
Solved via iterative PnP with **RANSAC** (inlier threshold=8 px).

4. **Pose refinement**: bundle adjustment over a local window of keyframes using
   g2o (graph optimisation), minimising reprojection error over all visible landmarks.

### 3.5 Loop Closure

ORB-SLAM2 detects loops using **DBoW2** (bag-of-words on ORB descriptors):

1. Convert current keyframe descriptors → BoW vector v ∈ ℝ^V
2. Query database; accept candidate if similarity score > threshold
3. Compute **Sim3** alignment (allows scale correction for monocular):
   s, R, t = Sim3_estimator(matched_3D_points)
4. Propagate correction via **Essential Graph** optimisation

For RGB-D mode, scale is fixed (s=1), so only SE(3) correction is applied.

### 3.6 Pose Representation

ORB-SLAM2 outputs T_cw ∈ SE(3) (4×4, camera-to-world).
Node C inverts it to get T_wc (world←camera) for ROS convention:

```
T_wc = T_cw⁻¹ = [R_wc | t_wc; 0 | 1]
```

Translation t_wc is published as `pose.position`.
R_wc is converted to quaternion q = (x,y,z,w) via the Shepperd method.

---

## 4. Real-Time Performance Analysis

### 4.1 Compute Budget (Jetson Orin Nano Super, 8 GB, 2 GB GPU effective)

| Stage | Compute | Latency (ms) |
|---|---|---|
| GStreamer camera capture | Hardware (NVMM) | ~0 |
| Node A publish | CPU copy | ~2 |
| Node B: ViT-Small FP16 (518px) | CUDA | 120–200 |
| Node B: ViT-Small FP16 (384px) | CUDA | 80–120 |
| Node C: ORB extraction | CPU | 25–40 |
| Node C: PnP + RANSAC | CPU | 5–15 |
| Node C: Local BA (g2o) | CPU | 10–30 |
| **Total end-to-end** | | **~150–280 ms** |

**Effective rate**: ~5–8 Hz with 518px input, ~8–12 Hz with 384px.

### 4.2 Bottleneck: Depth Estimation

The ViT-Small backbone is the main bottleneck. Strategies to improve:

| Strategy | Expected Gain |
|---|---|
| Use FP16 (already applied) | 1.5× vs FP32 |
| Reduce input_size: 518→384 | ~1.5× |
| TensorRT export of model | 2–3× |
| Run depth at half rate, interpolate | 2× overall throughput |

### 4.3 Comparison to Real-Time (30 Hz threshold)

The system achieves **near-real-time** at 5–12 Hz, which is sufficient for indoor SLAM
(scene changes at human walking speed ~0.5 m/s, meaning 5 Hz gives ~10 cm per frame).
Full 30 Hz real-time would require a TensorRT-optimised depth model or dedicated depth
hardware.

---

## 5. Depth Quality vs Physical Sensor

| Metric | Intel RealSense D435 | Depth Anything V2 Small |
|---|---|---|
| Depth range | 0.1–10 m | 0–20 m (unconstrained) |
| Accuracy (RMSE, indoor) | ~2 mm | ~50–150 mm |
| Scale drift | None | None (metric model) |
| Texture dependency | None | Moderate (untextured surfaces) |
| Compute | Hardware (USB) | ~120–200 ms GPU |

Depth Anything V2 is noticeably worse than a physical depth sensor near edges,
on specular/transparent surfaces, and in low-texture regions. However, for SLAM
trajectory estimation where map-point density matters more than per-point precision,
it provides sufficient quality for indoor navigation.

---

## 6. Design Decisions

**Why Depth Anything V2 over UniDepth?**
- Smaller model (ViT-Small vs ViT-L options)
- HuggingFace `pipeline()` API simplifies integration
- Indoor-metric variant trained on NYU/KITTI gives consistent scale for SLAM

**Why TUM fr1/desk for validation?**
- Ground truth trajectory available (motion capture)
- Short sequences (868 frames) allow fast iteration
- Camera intrinsics well-documented for ORB-SLAM2

**Why approximate time synchronisation?**
- Depth inference latency (~150 ms) means depth messages always arrive later than RGB
- `ApproximateTimeSynchronizer` (slop=50 ms) correctly pairs them by original capture time

---

## 7. Known Limitations

1. **Depth scale error** on reflective surfaces (glass, screens) causes SLAM drift
2. **Initialisation** requires sufficient parallax — slow movements may cause LOST state
3. **Loop closure** requires returning to a previously visited area (not guaranteed in short sequences)
4. **GStreamer + ROS 2** latency jitter (~10–20 ms) may cause occasional sync misses

---

## 8. References

1. Mur-Artal, R., & Tardós, J. D. (2017). ORB-SLAM2: An Open-Source SLAM System for Monocular, Stereo, and RGB-D Cameras. *IEEE TRO*.
2. Yang, L., et al. (2024). Depth Anything V2. *NeurIPS 2024*.
3. Ranftl, R., et al. (2021). Vision Transformers for Dense Prediction (DPT). *ICCV 2021*.
4. Gálvez-López, D., & Tardós, J.D. (2012). Bags of Binary Words for Fast Place Recognition in Image Sequences. *IEEE TRO*.
5. TUM RGB-D Benchmark: https://cvg.cit.tum.de/data/datasets/rgbd-dataset
