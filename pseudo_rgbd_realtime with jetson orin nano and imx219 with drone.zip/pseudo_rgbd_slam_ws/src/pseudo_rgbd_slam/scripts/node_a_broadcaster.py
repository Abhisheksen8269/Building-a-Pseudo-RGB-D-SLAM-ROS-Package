#!/usr/bin/env python3
"""
Node A: Broadcaster — IMX219 via GStreamer + TUM dataset
--------------------------------------------------------
KEY FIXES:
  1. Publishes at 5 Hz max when depth is on CPU (throttle to match depth rate)
     Change publish_rate param to 15 when GPU depth is working
  2. RELIABLE QoS on publisher so Node C's message_filters can receive it
"""

import os, sys, time
os.environ.pop("DISPLAY", None)

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy
from sensor_msgs.msg import Image, CameraInfo
import cv2
import numpy as np
from cv_bridge import CvBridge


class BroadcasterNode(Node):

    def __init__(self):
        super().__init__('node_a_broadcaster')

        self.declare_parameter('source',        'camera')
        self.declare_parameter('dataset_path',  '')
        self.declare_parameter('publish_rate',  5.0)    # 5Hz for CPU depth; 15Hz with GPU
        self.declare_parameter('camera_width',  960)
        self.declare_parameter('camera_height', 540)
        self.declare_parameter('sensor_id',     0)

        self.source       = self.get_parameter('source').value
        self.dataset_path = self.get_parameter('dataset_path').value
        self.rate_hz      = self.get_parameter('publish_rate').value
        self.cam_w        = self.get_parameter('camera_width').value
        self.cam_h        = self.get_parameter('camera_height').value
        self.sensor_id    = self.get_parameter('sensor_id').value

        # RELIABLE so message_filters in Node C can sync properly
        qos = QoSProfile(
            reliability=QoSReliabilityPolicy.RELIABLE,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=10,
        )

        self.pub_image = self.create_publisher(Image,      '/camera/image_raw',   qos)
        self.pub_info  = self.create_publisher(CameraInfo, '/camera/camera_info', qos)
        self.bridge    = CvBridge()
        self.K, self.D = self._build_camera_info()

        if self.source == 'camera':
            self._setup_live_camera()
        else:
            self._setup_dataset()

        period = 1.0 / self.rate_hz
        self.timer = self.create_timer(period, self._publish_frame)
        self.get_logger().info(
            f'[Node A] Broadcaster started — source={self.source} @ {self.rate_hz} Hz')

    def _build_camera_info(self):
        fx_o, fy_o = 517.3, 516.5
        cx_o, cy_o = 318.6, 255.3
        sx = self.cam_w / 640.0
        sy = self.cam_h / 480.0
        K = np.array([fx_o*sx, 0, cx_o*sx,
                      0, fy_o*sy, cy_o*sy,
                      0, 0, 1.0], dtype=np.float64)
        D = np.array([0.2624, -0.9531, -0.0054, 0.0026, 1.1633], dtype=np.float64)
        return K, D

    def _gstreamer_pipeline(self):
        # Request exactly 15fps from sensor (even if we publish at 5Hz)
        return (
            f"nvarguscamerasrc sensor-id={self.sensor_id} ! "
            f"video/x-raw(memory:NVMM), width=(int)1920, height=(int)1080, "
            f"framerate=(fraction)15/1 ! "
            f"nvvidconv flip-method=0 ! "
            f"video/x-raw, width=(int){self.cam_w}, height=(int){self.cam_h}, "
            f"format=(string)BGRx ! "
            f"videoconvert ! "
            f"video/x-raw, format=(string)BGR ! appsink drop=true sync=false max-buffers=1"
        )

    def _setup_live_camera(self):
        pipeline = self._gstreamer_pipeline()
        self.get_logger().info(f'[Node A] GStreamer pipeline:\n{pipeline}')
        self.cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)
        if not self.cap.isOpened():
            self.get_logger().fatal('[Node A] Cannot open IMX219 camera!')
            sys.exit(1)
        self.get_logger().info('[Node A] IMX219 camera opened successfully.')

    def _setup_dataset(self):
        rgb_txt = os.path.join(self.dataset_path, 'rgb.txt')
        if not os.path.isfile(rgb_txt):
            self.get_logger().fatal(f'[Node A] rgb.txt not found at {rgb_txt}')
            sys.exit(1)
        self.dataset_frames = []
        with open(rgb_txt) as f:
            for line in f:
                line = line.strip()
                if line.startswith('#') or not line:
                    continue
                parts = line.split()
                self.dataset_frames.append(
                    (float(parts[0]), os.path.join(self.dataset_path, parts[1])))
        self.dataset_idx = 0
        self.get_logger().info(
            f'[Node A] Dataset: {len(self.dataset_frames)} frames')

    def _publish_frame(self):
        frame = self._read_live_frame() if self.source == 'camera' \
                else self._read_dataset_frame()
        if frame is None:
            return

        now      = self.get_clock().now().to_msg()
        frame_id = 'camera'

        img_msg              = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')
        img_msg.header.stamp    = now
        img_msg.header.frame_id = frame_id
        self.pub_image.publish(img_msg)

        info                     = CameraInfo()
        info.header.stamp        = now
        info.header.frame_id     = frame_id
        info.width               = self.cam_w
        info.height              = self.cam_h
        info.distortion_model    = 'plumb_bob'
        info.k                   = self.K.tolist()
        info.d                   = self.D.tolist()
        info.r                   = [1.,0.,0., 0.,1.,0., 0.,0.,1.]
        info.p                   = [self.K[0], 0., self.K[2], 0.,
                                    0., self.K[4], self.K[5], 0.,
                                    0., 0., 1., 0.]
        self.pub_info.publish(info)

    def _read_live_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().warn('[Node A] Dropped frame.')
            return None
        return frame

    def _read_dataset_frame(self):
        if self.dataset_idx >= len(self.dataset_frames):
            self.dataset_idx = 0
        _, path = self.dataset_frames[self.dataset_idx]
        self.dataset_idx += 1
        frame = cv2.imread(path)
        if frame is None:
            return None
        return cv2.resize(frame, (self.cam_w, self.cam_h))

    def destroy_node(self):
        if self.source == 'camera' and hasattr(self, 'cap'):
            self.cap.release()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = BroadcasterNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
