#!/usr/bin/env python3
"""
Node C: Pseudo SLAM — Fixed for jskinn binding API
---------------------------------------------------
CRITICAL FIX: jskinn/ORB_SLAM2-PythonBindings API:
  - process_image_rgbd()  → returns bool (True=success), NOT a pose matrix
  - get_trajectory_points() → returns list of (timestamp, 4x4 pose) tuples
  - get_tracked_mappoints() → returns list of (world_pos_3d, keypoint_2d) tuples
    where world_pos_3d is a tuple/list of 3 floats

So the correct flow is:
  1. Call process_image_rgbd(rgb, depth, timestamp) → bool
  2. Call get_tracking_state()
  3. Call get_trajectory_points() → get LAST entry for current pose
  4. Call get_tracked_mappoints() → extract 3D positions
"""

import os, sys, time, threading
os.environ.pop("DISPLAY", None)

import rclpy
from rclpy.node import Node
from rclpy.qos import (QoSProfile, QoSReliabilityPolicy,
                        QoSHistoryPolicy, QoSDurabilityPolicy)
from sensor_msgs.msg import Image, PointCloud2, PointField
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Path
from std_msgs.msg import String
import numpy as np
import cv2
from cv_bridge import CvBridge

try:
    import message_filters
    HAS_SYNC = True
except ImportError:
    HAS_SYNC = False


def rot2quat(R):
    trace = R[0,0] + R[1,1] + R[2,2]
    if trace > 0:
        s = 0.5 / np.sqrt(trace + 1.0)
        return (R[2,1]-R[1,2])*s, (R[0,2]-R[2,0])*s, (R[1,0]-R[0,1])*s, 0.25/s
    elif R[0,0] > R[1,1] and R[0,0] > R[2,2]:
        s = 2.0*np.sqrt(1.0+R[0,0]-R[1,1]-R[2,2])
        return 0.25*s, (R[0,1]+R[1,0])/s, (R[0,2]+R[2,0])/s, (R[2,1]-R[1,2])/s
    elif R[1,1] > R[2,2]:
        s = 2.0*np.sqrt(1.0+R[1,1]-R[0,0]-R[2,2])
        return (R[0,1]+R[1,0])/s, 0.25*s, (R[1,2]+R[2,1])/s, (R[0,2]-R[2,0])/s
    else:
        s = 2.0*np.sqrt(1.0+R[2,2]-R[0,0]-R[1,1])
        return (R[0,2]+R[2,0])/s, (R[1,2]+R[2,1])/s, 0.25*s, (R[1,0]-R[0,1])/s


def make_pc2(xyz_list, frame_id, stamp):
    """Build PointCloud2 from list of (x,y,z) tuples/arrays."""
    if not xyz_list:
        return None
    pts = np.array(xyz_list, dtype=np.float32)
    if pts.ndim != 2 or pts.shape[1] != 3:
        return None
    # Filter out NaN/inf
    valid = np.all(np.isfinite(pts), axis=1)
    pts = pts[valid]
    if len(pts) == 0:
        return None

    msg = PointCloud2()
    msg.header.stamp    = stamp
    msg.header.frame_id = frame_id
    msg.height = 1
    msg.width  = len(pts)
    msg.is_dense     = False
    msg.is_bigendian = False
    msg.point_step   = 12
    msg.row_step     = 12 * len(pts)
    msg.fields = [
        PointField(name='x', offset=0,  datatype=PointField.FLOAT32, count=1),
        PointField(name='y', offset=4,  datatype=PointField.FLOAT32, count=1),
        PointField(name='z', offset=8,  datatype=PointField.FLOAT32, count=1),
    ]
    msg.data = pts.tobytes()
    return msg


def extract_pose_from_trajectory(traj_points):
    """
    jskinn binding: get_trajectory_points() returns list of
      (timestamp_float, pose_4x4_as_nested_list_or_numpy)
    We want the LAST entry = current pose.
    Returns 4x4 numpy array or None.
    """
    if not traj_points:
        return None
    last = traj_points[-1]
    try:
        # last is (timestamp, pose_matrix)
        if isinstance(last, (list, tuple)) and len(last) == 2:
            pose = np.array(last[1], dtype=np.float64)
        else:
            pose = np.array(last, dtype=np.float64)
        if pose.shape == (4, 4):
            return pose
        # Sometimes it's flattened (16,) — reshape
        if pose.size == 16:
            return pose.reshape(4, 4)
    except Exception:
        pass
    return None


def extract_mappoints(raw_pts):
    """
    jskinn binding: get_tracked_mappoints() returns list of
      ((x,y,z), (u,v))   — world position + image keypoint
    We only need the 3D world position.
    Returns list of [x,y,z] arrays.
    """
    xyz = []
    if raw_pts is None:
        return xyz
    for item in raw_pts:
        if item is None:
            continue
        try:
            # Item is ((x,y,z), (u,v))
            if isinstance(item, (list, tuple)) and len(item) == 2:
                world_pos = item[0]
            else:
                world_pos = item
            arr = np.array(world_pos, dtype=np.float32).flatten()
            if arr.shape == (3,) and np.all(np.isfinite(arr)):
                xyz.append(arr)
        except Exception:
            continue
    return xyz


class PseudoSLAMNode(Node):

    def __init__(self):
        super().__init__('node_c_pseudo_slam')

        self.declare_parameter('vocab_path',
            '/home/nvidia/ORB_SLAM2/Vocabulary/ORBvoc.txt')
        self.declare_parameter('settings_path',
            '/home/nvidia/pseudo_rgbd_slam_ws/src/pseudo_rgbd_slam/config/TUM1_960x540.yaml')
        self.declare_parameter('use_viewer',    False)
        self.declare_parameter('world_frame',   'map')
        self.declare_parameter('depth_factor',  1.0)
        self.declare_parameter('sync_slop_sec', 1.0)   # GPU depth ~100ms, 1s slop is safe

        self.vocab_path    = self.get_parameter('vocab_path').value
        self.settings_path = self.get_parameter('settings_path').value
        self.use_viewer    = self.get_parameter('use_viewer').value
        self.world_frame   = self.get_parameter('world_frame').value
        self.depth_factor  = self.get_parameter('depth_factor').value
        self.sync_slop     = self.get_parameter('sync_slop_sec').value

        # ── QoS ───────────────────────────────────────────────────────────
        qos_be = QoSProfile(depth=10,
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST)
        qos_rel = QoSProfile(depth=10,
            reliability=QoSReliabilityPolicy.RELIABLE,
            history=QoSHistoryPolicy.KEEP_LAST)
        qos_map = QoSProfile(depth=1,
            reliability=QoSReliabilityPolicy.RELIABLE,
            history=QoSHistoryPolicy.KEEP_LAST,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL)

        self.pub_pose   = self.create_publisher(PoseStamped, '/slam/pose',       10)
        self.pub_traj   = self.create_publisher(Path,        '/slam/trajectory', 10)
        self.pub_map    = self.create_publisher(PointCloud2, '/slam/map_points', qos_map)
        self.pub_status = self.create_publisher(String,      '/slam/status',     10)

        self.bridge     = CvBridge()
        self.trajectory = []
        self._frame_cnt = 0
        self._slam      = None
        self._slam_lock = threading.Lock()

        threading.Thread(target=self._load_orbslam2, daemon=True).start()

        # ── Manual cache sync (most robust approach) ──────────────────────
        self._rgb_cache   = None
        self._depth_cache = None
        self._cache_lock  = threading.Lock()
        self._last_processed_depth_stamp = None

        # Node A publishes RELIABLE, Node B publishes RELIABLE
        self.create_subscription(Image, '/camera/image_raw',
            self._rgb_cb, qos_rel)
        self.create_subscription(Image, '/depth/image_raw',
            self._depth_cb, qos_rel)

        self.get_logger().info('[Node C] Pseudo SLAM node started.')

    # ──────────────────────────────────────────────────────────────────────
    def _load_orbslam2(self):
        try:
            import orbslam2
            self.get_logger().info('[Node C] Loading ORB vocabulary (may take 30s)...')
            with self._slam_lock:
                self._slam = orbslam2.System(
                    self.vocab_path,
                    self.settings_path,
                    orbslam2.Sensor.RGBD,
                )
                self._slam.set_use_viewer(self.use_viewer)
                self._slam.initialize()
            self.get_logger().info('[Node C] ✓ ORB-SLAM2 initialised and ready.')

            # Log API to help diagnose binding version
            api = [m for m in dir(self._slam) if not m.startswith('_')]
            self.get_logger().info(f'[Node C] orbslam2 API: {api}')

        except ImportError as e:
            self.get_logger().error(f'[Node C] orbslam2 not found: {e}')
        except Exception as e:
            self.get_logger().error(f'[Node C] Init error: {e}')
            import traceback; traceback.print_exc()

    # ──────────────────────────────────────────────────────────────────────
    def _rgb_cb(self, msg):
        with self._cache_lock:
            self._rgb_cache = msg

    def _depth_cb(self, msg):
        # Each new depth triggers a SLAM step with the latest RGB
        with self._cache_lock:
            self._depth_cache = msg
            rgb = self._rgb_cache

        if rgb is None:
            return

        # Avoid reprocessing same depth frame
        depth_stamp_ns = (rclpy.time.Time.from_msg(msg.header.stamp).nanoseconds)
        if depth_stamp_ns == self._last_processed_depth_stamp:
            return
        self._last_processed_depth_stamp = depth_stamp_ns

        self._process_pair(rgb, msg)

    # ──────────────────────────────────────────────────────────────────────
    def _process_pair(self, rgb_msg, depth_msg):
        with self._slam_lock:
            if self._slam is None:
                self.get_logger().warn('[Node C] SLAM not ready yet, skipping frame')
                return

        self._frame_cnt += 1
        t0 = time.time()

        try:
            bgr   = self.bridge.imgmsg_to_cv2(rgb_msg,   desired_encoding='bgr8')
            depth = self.bridge.imgmsg_to_cv2(depth_msg, desired_encoding='32FC1')

            depth_m = np.nan_to_num(
                (depth * self.depth_factor).astype(np.float32),
                nan=0.0, posinf=0.0, neginf=0.0)

            # Use RGB frame's timestamp for SLAM
            timestamp = (rclpy.time.Time.from_msg(rgb_msg.header.stamp)
                         .nanoseconds * 1e-9)

            with self._slam_lock:
                # ── jskinn API: returns bool ──────────────────────────────
                success = self._slam.process_image_rgbd(bgr, depth_m, timestamp)
                state   = self._slam.get_tracking_state()

                # ── Get pose from trajectory (not from return value) ──────
                try:
                    traj = self._slam.get_trajectory_points()
                except Exception:
                    traj = []

                # ── Get map points ────────────────────────────────────────
                try:
                    raw_pts = self._slam.get_tracked_mappoints()
                except Exception:
                    raw_pts = []

            dt_ms = (time.time() - t0) * 1000
            states = {1: 'NOT_INIT', 2: 'OK', 3: 'LOST'}
            status_str = states.get(state, f'STATE_{state}')

            self.get_logger().info(
                f'[Node C] frame={self._frame_cnt} state={status_str} '
                f'ok={success} traj_len={len(traj) if traj else 0} '
                f'pts={len(raw_pts) if raw_pts else 0} slam_ms={dt_ms:.0f}')

            self.pub_status.publish(String(data=status_str))

            now = rgb_msg.header.stamp

            # ── Extract and publish pose ───────────────────────────────────
            pose_mat = extract_pose_from_trajectory(traj)
            if pose_mat is not None:
                # Trajectory stores T_wc directly (world←camera) in jskinn
                # If positions look wrong, swap to np.linalg.inv(pose_mat)
                T_wc = pose_mat
                R = T_wc[:3, :3]
                t = T_wc[:3,  3]
                x, y, z, w = rot2quat(R)

                ps = PoseStamped()
                ps.header.stamp    = now
                ps.header.frame_id = self.world_frame
                ps.pose.position.x    = float(t[0])
                ps.pose.position.y    = float(t[1])
                ps.pose.position.z    = float(t[2])
                ps.pose.orientation.x = float(x)
                ps.pose.orientation.y = float(y)
                ps.pose.orientation.z = float(z)
                ps.pose.orientation.w = float(w)
                self.pub_pose.publish(ps)

                self.trajectory.append(ps)
                path = Path()
                path.header.stamp    = now
                path.header.frame_id = self.world_frame
                path.poses = self.trajectory[-2000:]
                self.pub_traj.publish(path)

                self.get_logger().info(
                    f'[Node C] ✓ Pose t=[{t[0]:.3f},{t[1]:.3f},{t[2]:.3f}]')

            # ── Extract and publish map points ─────────────────────────────
            xyz = extract_mappoints(raw_pts)
            if xyz:
                pc2 = make_pc2(xyz, self.world_frame, now)
                if pc2 is not None:
                    self.pub_map.publish(pc2)
                    self.get_logger().info(f'[Node C] ✓ {len(xyz)} map points published')
            else:
                if self._frame_cnt <= 5 or self._frame_cnt % 20 == 0:
                    self.get_logger().warn(
                        f'[Node C] No map points at frame {self._frame_cnt} '
                        f'(state={status_str}). Move camera slowly for init.')

        except Exception as e:
            self.get_logger().error(f'[Node C] Processing error: {e}')
            import traceback; traceback.print_exc()

    def destroy_node(self):
        with self._slam_lock:
            if self._slam is not None:
                try:
                    self._slam.shutdown()
                except Exception:
                    pass
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = PseudoSLAMNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
