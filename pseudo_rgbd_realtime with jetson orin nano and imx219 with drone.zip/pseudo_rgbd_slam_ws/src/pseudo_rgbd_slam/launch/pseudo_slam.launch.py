"""
pseudo_slam.launch.py
=====================
Launches all three nodes:
  Node A  — Broadcaster   (camera or dataset)
  Node B  — Depth Estimator
  Node C  — Pseudo SLAM

Usage examples:
  # Live camera
  ros2 launch pseudo_rgbd_slam pseudo_slam.launch.py source:=camera

  # TUM fr1/desk dataset
  ros2 launch pseudo_rgbd_slam pseudo_slam.launch.py \
      source:=dataset \
      dataset_path:=/data/tum/rgbd_dataset_freiburg1_desk
"""

import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    pkg = FindPackageShare('pseudo_rgbd_slam')

    # ── Launch arguments ──────────────────────────────────────────────────────
    arg_source = DeclareLaunchArgument(
        'source', default_value='camera',
        description="'camera' for live IMX219, 'dataset' for TUM fr1/desk")

    arg_dataset = DeclareLaunchArgument(
        'dataset_path', default_value='',
        description='Absolute path to TUM dataset root directory')

    arg_rate = DeclareLaunchArgument(
        'publish_rate', default_value='15.0',
        description='Frame publish rate in Hz (reduce for depth-estimator headroom)')

    arg_device = DeclareLaunchArgument(
        'device', default_value='cuda',
        description="'cuda' or 'cpu' for depth model")

    arg_vocab = DeclareLaunchArgument(
        'vocab_path',
        default_value='/home/nvidia/ORB_SLAM2/Vocabulary/ORBvoc.txt',
        description='Path to ORB_SLAM2 vocabulary file')

    arg_settings = DeclareLaunchArgument(
        'settings_path',
        default_value='/home/nvidia/pseudo_rgbd_slam_ws/src/pseudo_rgbd_slam/config/pseudo_slam_camera.yaml',
        description='Path to ORB_SLAM2 RGB-D settings YAML')

    arg_rviz = DeclareLaunchArgument(
        'rviz', default_value='true',
        description='Launch RViz2 for visualisation')

    # ── Node A — Broadcaster ──────────────────────────────────────────────────
    node_a = Node(
        package='pseudo_rgbd_slam',
        executable='node_a_broadcaster.py',
        name='node_a_broadcaster',
        output='screen',
        parameters=[{
            'source':        LaunchConfiguration('source'),
            'dataset_path':  LaunchConfiguration('dataset_path'),
            'publish_rate':  LaunchConfiguration('publish_rate'),
            'camera_width':  960,
            'camera_height': 540,
            'sensor_id':     0,
        }],
        remappings=[],
    )

    # ── Node B — Depth Estimator ───────────────────────────────────────────────
    node_b = Node(
        package='pseudo_rgbd_slam',
        executable='node_b_depth_estimator.py',
        name='node_b_depth_estimator',
        output='screen',
        parameters=[{
            'model_name':     'depth-anything/Depth-Anything-V2-Metric-Indoor-Small-hf',
            'device':         LaunchConfiguration('device'),
            'input_size':     518,
            'publish_colormap': True,
            'max_depth_m':    10.0,
        }],
    )

    # ── Node C — Pseudo SLAM ───────────────────────────────────────────────────
    node_c = Node(
        package='pseudo_rgbd_slam',
        executable='node_c_pseudo_slam.py',
        name='node_c_pseudo_slam',
        output='screen',
        parameters=[{
            'vocab_path':    LaunchConfiguration('vocab_path'),
            'settings_path': LaunchConfiguration('settings_path'),
            'use_viewer':    False,
            'depth_factor':  1.0,
            'sync_slop_sec': 0.05,
        }],
    )

    # ── RViz2 ─────────────────────────────────────────────────────────────────
    rviz_cfg = PathJoinSubstitution([pkg, 'rviz', 'pseudo_slam.rviz'])
    node_rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_cfg],
        output='screen',
        condition=__import__('launch.conditions', fromlist=['IfCondition']).IfCondition(
            LaunchConfiguration('rviz')),
    )

    return LaunchDescription([
        arg_source, arg_dataset, arg_rate, arg_device,
        arg_vocab, arg_settings, arg_rviz,
        LogInfo(msg='=== Pseudo RGB-D SLAM — launching all nodes ==='),
        node_a,
        node_b,
        node_c,
        node_rviz,
    ])
