# Pseudo RGB-D SLAM — Complete Installation Guide
## Jetson Orin Nano Super Developer Kit · Ubuntu 22.04 · ROS 2 Humble

---

## Table of Contents
1. [Hardware Prerequisites](#1-hardware-prerequisites)
2. [System Preparation](#2-system-preparation)
3. [ROS 2 Humble Installation](#3-ros-2-humble-installation)
4. [GStreamer & Camera Verification](#4-gstreamer--camera-verification)
5. [Python Dependencies](#5-python-dependencies)
6. [ORB-SLAM2 Build & Python Bindings](#6-orb-slam2-build--python-bindings)
7. [Depth Anything V2 Model Download](#7-depth-anything-v2-model-download)
8. [Build the ROS 2 Package](#8-build-the-ros-2-package)
9. [TUM Dataset Download](#9-tum-dataset-download)
10. [Running the System](#10-running-the-system)
11. [Screen Recording for Submission](#11-screen-recording-for-submission)
12. [Troubleshooting](#12-troubleshooting)

---

## 1. Hardware Prerequisites

| Item | Spec |
|---|---|
| Board | Jetson Orin Nano Super Developer Kit (8 GB) |
| OS | JetPack 6.x (Ubuntu 22.04, L4T R36.x) |
| Camera | IMX219 (Raspberry Pi Camera v2 compatible) |
| Storage | ≥ 32 GB (model + dataset) |
| RAM | 8 GB unified (GPU + CPU share) |

---

## 2. System Preparation

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Essential build tools
sudo apt install -y \
  build-essential cmake git curl wget unzip \
  python3-pip python3-dev python3-venv \
  libssl-dev libffi-dev \
  v4l-utils nano htop

# Check JetPack version
cat /etc/nv_tegra_release   # Should show R36.x

# Check GPU
nvidia-smi                  # Should show Ampere GPU

# Verify CUDA
nvcc --version              # Should show CUDA 12.x
```

---

## 3. ROS 2 Humble Installation

> Skip this section if ROS 2 Humble is already installed.

```bash
# Set locale
sudo apt install -y locales
sudo locale-gen en_US en_US.UTF-8
sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
export LANG=en_US.UTF-8

# Add ROS 2 apt repository
sudo apt install -y software-properties-common
sudo add-apt-repository universe
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
  -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) \
  signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] \
  http://packages.ros.org/ros2/ubuntu \
  $(. /etc/os-release && echo $UBUNTU_CODENAME) main" \
  | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

# Install ROS 2 Humble Desktop
sudo apt update
sudo apt install -y ros-humble-desktop

# Install development tools
sudo apt install -y \
  python3-rosdep python3-rosinstall python3-rosinstall-generator \
  python3-wstool python3-colcon-common-extensions \
  ros-humble-cv-bridge ros-humble-image-transport \
  ros-humble-message-filters ros-humble-tf2-ros \
  ros-humble-tf2-geometry-msgs ros-humble-visualization-msgs

# Initialise rosdep
sudo rosdep init
rosdep update

# Add to ~/.bashrc
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
source ~/.bashrc

# Verify
ros2 --version   # should print "ros2 cli version 0.18.x"
```

---

## 4. GStreamer & Camera Verification

```bash
# Install GStreamer + Jetson Multimedia API plugins
sudo apt install -y \
  gstreamer1.0-tools \
  gstreamer1.0-plugins-base \
  gstreamer1.0-plugins-good \
  gstreamer1.0-plugins-bad \
  gstreamer1.0-plugins-ugly \
  gstreamer1.0-libav \
  python3-gi python3-gi-cairo gir1.2-gst-plugins-base-1.0

# Verify Argus camera daemon is running
systemctl status nvargus-daemon
# If not running:
sudo systemctl start nvargus-daemon
sudo systemctl enable nvargus-daemon

# Quick camera test (should show a window or stream)
# ❗ Run this WITHOUT sudo (nvargus needs user permissions)
python3 - <<'EOF'
import cv2, os
if 'DISPLAY' in os.environ: del os.environ['DISPLAY']
pipeline = (
    "nvarguscamerasrc sensor-id=0 ! "
    "video/x-raw(memory:NVMM), width=1920, height=1080, framerate=30/1 ! "
    "nvvidconv flip-method=0 ! "
    "video/x-raw, width=960, height=540, format=BGRx ! "
    "videoconvert ! video/x-raw, format=BGR ! appsink drop=true sync=false"
)
cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)
print("Camera opened:", cap.isOpened())
ret, frame = cap.read()
print("Frame captured:", ret, frame.shape if ret else "N/A")
cap.release()
EOF
```

---

## 5. Python Dependencies

```bash
# Upgrade pip
pip3 install --upgrade pip setuptools wheel

# ── PyTorch with CUDA (JetPack 6 / L4T R36) ──────────────────────────────────
# Use NVIDIA's pre-built wheel — DO NOT use pip's default torch
# (it won't have Tegra/CUDA support)

# Check L4T version
python3 -c "import subprocess; print(subprocess.check_output(['cat','/etc/nv_tegra_release']).decode())"

# Download PyTorch for JetPack 6 (aarch64, CUDA 12)
# Visit: https://forums.developer.nvidia.com/t/pytorch-for-jetson/72048
# For JetPack 6.x use the wheel for torch 2.3+ aarch64:
wget -O torch-2.3.0-cp310-cp310-linux_aarch64.whl \
  "https://developer.download.nvidia.com/compute/redist/jp/v61/pytorch/torch-2.3.0+nv24.5-cp310-cp310-linux_aarch64.whl"
pip3 install torch-2.3.0-cp310-cp310-linux_aarch64.whl

# torchvision (must match torch version)
pip3 install torchvision==0.18.0

# Verify CUDA is available
python3 -c "import torch; print('CUDA:', torch.cuda.is_available(), torch.version.cuda)"

# ── HuggingFace Transformers (for Depth Anything V2) ──────────────────────────
pip3 install transformers accelerate huggingface_hub

# ── OpenCV (already on Jetson via JetPack, verify) ────────────────────────────
python3 -c "import cv2; print(cv2.__version__, cv2.getBuildInformation())" | grep -i cuda

# If OpenCV lacks CUDA, rebuild it (optional, ~45 min):
# See: https://docs.opencv.org/4.x/d6/d15/tutorial_building_tegra_cuda.html

# ── Other Python deps ─────────────────────────────────────────────────────────
pip3 install \
  numpy scipy Pillow \
  rclpy cv_bridge \
  matplotlib tqdm

echo "✓ Python dependencies installed."
```

---

## 6. ORB-SLAM2 Build & Python Bindings

```bash
# ── System dependencies for ORB-SLAM2 ────────────────────────────────────────
sudo apt install -y \
  libglew-dev libpangolin-dev \
  libeigen3-dev \
  libopencv-dev \
  libboost-serialization-dev

# Build Pangolin (if not installed)
cd ~
git clone https://github.com/stevenlovegrove/Pangolin.git
cd Pangolin
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(nproc)
sudo make install
cd ~

# ── Clone ORB-SLAM2 ───────────────────────────────────────────────────────────
git clone https://github.com/raulmur/ORB_SLAM2.git ~/ORB_SLAM2
cd ~/ORB_SLAM2

# ── Fix compilation for modern GCC ───────────────────────────────────────────
# Replace deprecated usleep with this_thread::sleep_for
find . -name "*.cc" -exec sed -i 's/usleep(/std::this_thread::sleep_for(std::chrono::microseconds(/g; s/usleep(\(.*\))/std::this_thread::sleep_for(std::chrono::microseconds(\1))/g' {} \;

# Add missing includes
sed -i '1s/^/#include <unistd.h>\n/' include/System.h

# ── Build ORB-SLAM2 ───────────────────────────────────────────────────────────
chmod +x build.sh
./build.sh

# Verify: check lib was created
ls lib/libORB_SLAM2.so

# ── Build ORB-SLAM2 Python Bindings ──────────────────────────────────────────
# We use the orbslam2_python fork
cd ~
git clone https://github.com/jskinn/orbslam2_python.git
cd orbslam2_python

# Edit setup.py to point to your ORB_SLAM2 build
# Update these three paths in setup.py:
ORB_SLAM2_DIR=~/ORB_SLAM2
sed -i "s|/path/to/ORB_SLAM2|${HOME}/ORB_SLAM2|g" setup.py

# Build
pip3 install -e .

# Verify
python3 -c "import orbslam2; print('ORB-SLAM2 Python bindings: OK')"

# ── Download ORBvoc.txt.tar.gz vocabulary ─────────────────────────────────────
cd ~/ORB_SLAM2/Vocabulary
# It ships with the repo but compressed:
tar -xf ORBvoc.txt.tar.gz
ls ORBvoc.txt   # should be ~40 MB

echo "✓ ORB-SLAM2 built successfully."
```

---

## 7. Depth Anything V2 Model Download

The model auto-downloads from HuggingFace on first run.
To pre-download (recommended for offline use):

```bash
# Set cache directory (optional, saves to ~/.cache/huggingface by default)
export HF_HOME=/data/hf_cache   # change to your preferred path
mkdir -p $HF_HOME

# Pre-download the model weights (~140 MB)
python3 - <<'EOF'
from transformers import pipeline
print("Downloading Depth Anything V2 Metric Indoor Small …")
pipe = pipeline(
    task='depth-estimation',
    model='depth-anything/Depth-Anything-V2-Metric-Indoor-Small-hf',
)
print("✓ Model downloaded and cached.")
EOF
```

**Alternative: UniDepth (if you prefer)**

```bash
pip3 install unidepth-pytorch
# Change model_name parameter in node_b to use UniDepth wrapper
```

---

## 8. Build the ROS 2 Package

```bash
# Source ROS 2
source /opt/ros/humble/setup.bash

# Navigate to workspace
cd ~/pseudo_rgbd_slam_ws

# Resolve dependencies
rosdep install --from-paths src --ignore-src -r -y

# Build
colcon build --symlink-install --cmake-args -DCMAKE_BUILD_TYPE=Release

# Source the workspace
source install/setup.bash

# Add to ~/.bashrc
echo "source ~/pseudo_rgbd_slam_ws/install/setup.bash" >> ~/.bashrc

# Verify nodes are discoverable
ros2 pkg list | grep pseudo_rgbd_slam
```

---

## 9. TUM Dataset Download

```bash
# Create data directory
mkdir -p /data/tum && cd /data/tum

# Download fr1/desk (528 MB)
wget https://cvg.cit.tum.de/rgbd/dataset/freiburg1/rgbd_dataset_freiburg1_desk.tgz
tar -xzf rgbd_dataset_freiburg1_desk.tgz

# Verify structure
ls rgbd_dataset_freiburg1_desk/
# Expected: rgb/  depth/  rgb.txt  depth.txt  groundtruth.txt  accelerometer.txt
```

---

## 10. Running the System

### Option A — Live IMX219 Camera

**Terminal 1** (source both setups first):
```bash
source /opt/ros/humble/setup.bash
source ~/pseudo_rgbd_slam_ws/install/setup.bash

# Export display if you have a monitor attached (else leave unset)
# export DISPLAY=:0

ros2 launch pseudo_rgbd_slam pseudo_slam.launch.py \
    source:=camera \
    publish_rate:=15.0 \
    device:=cuda \
    settings_path:=$HOME/pseudo_rgbd_slam_ws/src/pseudo_rgbd_slam/config/TUM1_960x540.yaml \
    vocab_path:=$HOME/ORB_SLAM2/Vocabulary/ORBvoc.txt
```

### Option B — TUM fr1/desk Dataset

```bash
source /opt/ros/humble/setup.bash
source ~/pseudo_rgbd_slam_ws/install/setup.bash

ros2 launch pseudo_rgbd_slam pseudo_slam.launch.py \
    source:=dataset \
    dataset_path:=/data/tum/rgbd_dataset_freiburg1_desk \
    publish_rate:=10.0 \
    device:=cuda \
    settings_path:=$HOME/ORB_SLAM2/Vocabulary/../Examples/RGB-D/TUM1.yaml \
    vocab_path:=$HOME/ORB_SLAM2/Vocabulary/ORBvoc.txt
```

### Monitoring Topics

```bash
# In a new terminal
source /opt/ros/humble/setup.bash

ros2 topic list
# /camera/image_raw
# /camera/camera_info
# /depth/image_raw
# /depth/image_visual
# /slam/pose
# /slam/trajectory
# /slam/map_points
# /slam/status

# Check rates
ros2 topic hz /camera/image_raw      # ~15 Hz
ros2 topic hz /depth/image_raw       # ~5-8 Hz (GPU inference)
ros2 topic hz /slam/pose             # ~5-8 Hz (SLAM tracking)
ros2 topic hz /slam/status

# View SLAM status live
ros2 topic echo /slam/status
```

### RViz2 (if not auto-launched)

```bash
rviz2 -d ~/pseudo_rgbd_slam_ws/src/pseudo_rgbd_slam/rviz/pseudo_slam.rviz
```

In RViz, you should see **all three simultaneously**:
- Top-left panel: **RGB Feed** (`/camera/image_raw`)
- Top-right panel: **Depth Map** (`/depth/image_visual`)
- 3D view: **Trajectory** (green path) + **Map Points** (white dots)

---

## 11. Screen Recording for Submission

```bash
# Install ffmpeg
sudo apt install -y ffmpeg

# Record screen (replace :0 with your DISPLAY value)
ffmpeg -video_size 1920x1080 -framerate 15 \
       -f x11grab -i :0 \
       -c:v libx264 -preset ultrafast -crf 28 \
       slam_recording.mp4

# Stop recording: press q
```

For **Jetson headless** (SSH), use VNC:
```bash
sudo apt install -y tigervnc-standalone-server
vncserver :1 -geometry 1920x1080 -depth 24
export DISPLAY=:1
# Then record :1
```

---

## 12. Troubleshooting

### Camera won't open
```bash
# Check nvargus is running
systemctl status nvargus-daemon
sudo systemctl restart nvargus-daemon

# Check camera is detected
ls /dev/video*

# Test raw pipeline
gst-launch-1.0 nvarguscamerasrc sensor-id=0 ! \
  video/x-raw(memory:NVMM),width=640,height=480,framerate=30/1 ! \
  nvvidconv ! video/x-raw,format=I420 ! fakesink
```

### CUDA out of memory
```bash
# Use smaller input for depth model
# In node_b launch params: input_size:=384

# Or force CPU:
# device:=cpu  (slower, ~0.5 fps)
```

### ORB-SLAM2 LOST tracking
- Reduce `publish_rate` to give ORB-SLAM2 more processing time
- Ensure good lighting for the camera
- Check `ORBextractor.nFeatures` in config YAML

### Depth model download fails
```bash
# Set custom cache and proxy
export HF_HOME=/data/hf_cache
export HTTPS_PROXY=your_proxy  # if behind proxy
huggingface-cli login           # if model requires auth (this one doesn't)
```

### ROS 2 nodes not found after build
```bash
source ~/pseudo_rgbd_slam_ws/install/setup.bash
ros2 pkg prefix pseudo_rgbd_slam  # should print a path
```

### Sync issues between RGB and Depth
```bash
# Increase slop tolerance in launch
# sync_slop_sec:=0.1
```

---

## Performance Expectations (Jetson Orin Nano Super 8 GB)

| Component | Expected Rate | Notes |
|---|---|---|
| Node A: Camera publish | 30 Hz | GStreamer hardware accelerated |
| Node B: Depth estimation (CUDA FP16) | 5–8 Hz | ViT-Small, 518px input |
| Node B: Depth estimation (CPU) | ~0.5 Hz | Fallback only |
| Node C: ORB-SLAM2 tracking | 5–8 Hz | Gated by depth rate |
| End-to-end latency | ~150–250 ms | Camera → pose |

**Tip**: Run Node B with `input_size:=384` for ~9–12 Hz depth at modest accuracy cost.

---

## Architecture Summary

```
┌─────────────────────────────────────────────────────────────────┐
│                     Jetson Orin Nano Super                       │
│                                                                  │
│  IMX219                                                          │
│  Camera ──► nvarguscamerasrc (GStreamer HW)                      │
│              │                                                   │
│              ▼                                                   │
│  ┌─────────────────────────┐                                     │
│  │  Node A: Broadcaster    │  /camera/image_raw  (BGR, 960×540) │
│  │  (node_a_broadcaster)   │──────────────────────────►         │
│  └─────────────────────────┘                                     │
│              │                                                   │
│              ▼                                                   │
│  ┌─────────────────────────┐                                     │
│  │  Node B: Depth          │  /depth/image_raw   (float32, m)  │
│  │  (Depth Anything V2)    │──────────────────────────►         │
│  │  ViT-Small + DPT head   │  /depth/image_visual (colourmap)  │
│  └─────────────────────────┘                                     │
│         │              │                                         │
│         │ RGB          │ Depth                                   │
│         ▼              ▼                                         │
│  ┌─────────────────────────┐                                     │
│  │  Node C: Pseudo SLAM    │  /slam/pose        (PoseStamped)  │
│  │  (ORB-SLAM2 RGB-D)      │  /slam/trajectory  (Path)         │
│  │  Features→PnP→BA→Loop   │  /slam/map_points  (PointCloud2)  │
│  └─────────────────────────┘                                     │
│              │                                                   │
│              ▼                                                   │
│           RViz2 (RGB | Depth | Trajectory | Map)                 │
└─────────────────────────────────────────────────────────────────┘
```
