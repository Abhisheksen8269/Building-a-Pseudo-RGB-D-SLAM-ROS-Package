from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
import os


def generate_launch_description():
    home = os.path.expanduser('~')

    dataset_path  = LaunchConfiguration('dataset_path',
        default=os.path.join(home, 'datasets/tum/rgbd_dataset_freiburg1_desk'))
    vocab_path    = LaunchConfiguration('vocab_path',
        default=os.path.join(home, 'ORB_SLAM2/Vocabulary/ORBvoc.txt'))
    settings_path = LaunchConfiguration('settings_path',
        default=os.path.join(home, 'ros2_ws/src/pseudo_rgbd_slam/config/orb_slam2_rgbd.yaml'))

    return LaunchDescription([
        DeclareLaunchArgument('dataset_path',  default_value=dataset_path),
        DeclareLaunchArgument('vocab_path',    default_value=vocab_path),
        DeclareLaunchArgument('settings_path', default_value=settings_path),

        # Node A — RGB Broadcaster
        Node(
            package='pseudo_rgbd_slam',
            executable='node_a',
            name='node_a_broadcaster',
            output='screen',
            parameters=[{
                'dataset_path': dataset_path,
                'fps': 10.0,
                'loop': False,
            }]
        ),

        # Node B — Neural Depth Estimator
        Node(
            package='pseudo_rgbd_slam',
            executable='node_b',
            name='node_b_depth_estimator',
            output='screen',
            parameters=[{
                'model_name': 'unidepth-v2-vits14',
                'device': 'auto',
                'max_depth': 10.0,
            }]
        ),

        # Node C — SLAM
        Node(
            package='pseudo_rgbd_slam',
            executable='node_c',
            name='node_c_slam',
            output='screen',
            parameters=[{
                'vocab_path':    vocab_path,
                'settings_path': settings_path,
                'use_viewer':    False,
                'depth_scale':   1000.0,
                'max_depth':     10.0,
            }]
        ),

        # Node D — Visualizer
        Node(
            package='pseudo_rgbd_slam',
            executable='visualizer',
            name='node_d_visualizer',
            output='screen',
        ),
    ])
