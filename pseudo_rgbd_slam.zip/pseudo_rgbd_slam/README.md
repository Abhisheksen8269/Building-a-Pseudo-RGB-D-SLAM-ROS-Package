# Pseudo RGB-D SLAM ROS2 Package

## System Architecture

```
Node A (/rgb/image_raw) ──────────────────────────────────────→ Node C
                    └──→ Node B (/depth/image_raw) ──────────→ Node C
                                                                   ↓
                                                          /slam/pose
                                                          /slam/trajectory
                                                          /slam/tracking_viz
                                                               ↓
                                                          Node D (Visualizer)
```

## Prerequisites (all should be installed already)

```bash
# ROS2 Humble
source /opt/ros/humble/setup.bash

# Python deps
pip install torch torchvision opencv-python numpy
pip install git+https://github.com/lpiccinelli-eth/UniDepth.git

# ORB-SLAM2 built at ~/ORB_SLAM2
```

## Step 1 — Copy package to workspace

```bash
cp -r pseudo_rgbd_slam ~/ros2_ws/src/
```

## Step 2 — Build

```bash
cd ~/ros2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select pseudo_rgbd_slam --symlink-install
source install/setup.bash
```

## Step 3 — Download TUM dataset

```bash
mkdir -p ~/datasets/tum
cd ~/datasets/tum
wget https://cvg.cit.tum.de/rgbd/dataset/freiburg1/rgbd_dataset_freiburg1_desk.tgz
tar -xzf rgbd_dataset_freiburg1_desk.tgz
```

## Step 4 — Run (Launch all 4 nodes at once)

```bash
source ~/ros2_ws/install/setup.bash
ros2 launch pseudo_rgbd_slam slam_pipeline.launch.py
```

## Or run nodes individually (4 terminals)

```bash
# Terminal 1 — Node A
source ~/ros2_ws/install/setup.bash
ros2 run pseudo_rgbd_slam node_a \
  --ros-args -p dataset_path:=$HOME/datasets/tum/rgbd_dataset_freiburg1_desk -p fps:=10.0

# Terminal 2 — Node B
source ~/ros2_ws/install/setup.bash
ros2 run pseudo_rgbd_slam node_b \
  --ros-args -p model_name:=unidepth-v2-vits14 -p device:=auto

# Terminal 3 — Node C
source ~/ros2_ws/install/setup.bash
ros2 run pseudo_rgbd_slam node_c \
  --ros-args \
  -p vocab_path:=$HOME/ORB_SLAM2/Vocabulary/ORBvoc.txt \
  -p settings_path:=$HOME/ros2_ws/src/pseudo_rgbd_slam/config/orb_slam2_rgbd.yaml

# Terminal 4 — Visualizer (for screen recording)
source ~/ros2_ws/install/setup.bash
ros2 run pseudo_rgbd_slam visualizer
```

## Verify topics

```bash
ros2 topic list
ros2 topic hz /rgb/image_raw
ros2 topic hz /depth/image_raw
ros2 topic hz /slam/pose
```

## SLAM Backend

Node C automatically tries ORB-SLAM2 Python bindings first.
If unavailable, falls back to OpenCV RGB-D Visual Odometry (always works).
The fallback uses ORB features + PnP RANSAC for robust pose estimation.
