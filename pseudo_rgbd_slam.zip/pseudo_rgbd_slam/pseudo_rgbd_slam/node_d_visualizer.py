#!/usr/bin/env python3
"""
Node D: Visualizer — FAST VERSION
====================================
Key optimizations:
  1. Separate display thread — ROS callbacks never block on cv2.imshow
  2. Frame dropping — display always shows LATEST frame, never stale
  3. Resize once in display thread — not in callback
  4. Gradient trajectory color (blue→yellow = oldest→newest)
  5. FPS counter displayed on screen
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from nav_msgs.msg import Path
from cv_bridge import CvBridge

import cv2
import numpy as np
import threading
import time


class Visualizer(Node):
    def __init__(self):
        super().__init__('node_d_visualizer')

        self.bridge = CvBridge()
        self.lock   = threading.Lock()

        # Latest frames (always newest, not queued)
        self.rgb_frame   = None
        self.depth_frame = None
        self.track_frame = None
        self.trajectory  = []
        self.traj_pts    = 0

        # FPS tracking
        self._display_times = []
        self._last_fps = 0.0

        # Subscriptions — all non-blocking
        self.create_subscription(Image, '/rgb/image_raw',     self._cb_rgb,   5)
        self.create_subscription(Image, '/depth/colormap',    self._cb_depth, 5)
        self.create_subscription(Image, '/slam/tracking_viz', self._cb_track, 5)
        self.create_subscription(Path,  '/slam/trajectory',   self._cb_path,  5)

        # Display runs in a separate thread at ~25 FPS
        self._stop_event    = threading.Event()
        self._display_thread = threading.Thread(
            target=self._display_loop, daemon=True)
        self._display_thread.start()

        self.get_logger().info('Visualizer ready — press Q to quit')

    # ── Callbacks (store latest, never block) ─────────────────────────
    def _cb_rgb(self, msg):
        try:
            img = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            with self.lock:
                self.rgb_frame = img
        except Exception:
            pass

    def _cb_depth(self, msg):
        try:
            img = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            with self.lock:
                self.depth_frame = img
        except Exception:
            pass

    def _cb_track(self, msg):
        try:
            img = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            with self.lock:
                self.track_frame = img
        except Exception:
            pass

    def _cb_path(self, msg: Path):
        pts = [(p.pose.position.x, p.pose.position.z)
               for p in msg.poses]
        with self.lock:
            self.trajectory = pts
            self.traj_pts   = len(pts)

    # ── Trajectory Drawing ────────────────────────────────────────────
    def _draw_trajectory(self, W=500, H=340) -> np.ndarray:
        canvas = np.zeros((H, W, 3), np.uint8)

        with self.lock:
            pts = list(self.trajectory)
            n   = self.traj_pts

        # Axes
        cx, cy = W // 2, H // 2
        cv2.line(canvas, (cx, 8),    (cx, H-8),  (35,35,35), 1)
        cv2.line(canvas, (8,  cy),   (W-8, cy),  (35,35,35), 1)
        cv2.putText(canvas, f'Trajectory  n={n}',
                    (6, 14), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (180,180,255), 1)

        if len(pts) < 2:
            cv2.putText(canvas, 'Waiting for poses...',
                        (W//2-70, H//2), cv2.FONT_HERSHEY_SIMPLEX,
                        0.45, (120,120,120), 1)
            return canvas

        xs = [p[0] for p in pts]
        zs = [p[1] for p in pts]
        span  = max(max(abs(v) for v in xs+zs+[0.01]), 0.01)
        scale = min(W, H) * 0.42 / span

        # Draw gradient path (blue=old → yellow=new)
        npts = len(pts)
        for i in range(1, npts):
            r = i / npts
            color = (
                int(255*(1-r)),   # B fades out
                int(200*r),       # G increases
                int(255*r),       # R increases
            )
            x1 = int(pts[i-1][0]*scale + cx)
            y1 = int(pts[i-1][1]*scale + cy)
            x2 = int(pts[i][0]*scale   + cx)
            y2 = int(pts[i][1]*scale   + cy)
            cv2.line(canvas, (x1,y1), (x2,y2), color, 1)

        # Start marker (blue dot)
        sx = int(pts[0][0]*scale + cx)
        sy = int(pts[0][1]*scale + cy)
        cv2.circle(canvas, (sx,sy), 4, (255,100,0), -1)

        # Current position (bright green)
        ex = int(pts[-1][0]*scale + cx)
        ey = int(pts[-1][1]*scale + cy)
        cv2.circle(canvas, (ex,ey), 6,  (0,255,80), -1)
        cv2.circle(canvas, (ex,ey), 9,  (0,180,50),  1)

        cv2.putText(canvas, 'Z', (cx+3, 12),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.3, (80,80,80), 1)
        cv2.putText(canvas, 'X', (W-14, cy+4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.3, (80,80,80), 1)
        return canvas

    # ── Display Loop (separate thread) ────────────────────────────────
    def _display_loop(self):
        """Runs at 25 FPS independently of ROS callbacks."""
        target_period = 1.0 / 25.0

        while not self._stop_event.is_set():
            t0 = time.time()

            with self.lock:
                track = self.track_frame.copy() if self.track_frame is not None else None
                rgb   = self.rgb_frame.copy()   if self.rgb_frame   is not None else None
                depth = self.depth_frame.copy() if self.depth_frame is not None else None

            W, H = 640, 480

            # Top panel: tracking_viz (already RGB+Depth side by side)
            if track is not None:
                top = cv2.resize(track, (W*2, H))
            else:
                blank = np.zeros((H, W, 3), np.uint8)
                rgb_s   = cv2.resize(rgb,   (W,H)) if rgb   is not None else blank.copy()
                depth_s = cv2.resize(depth, (W,H)) if depth is not None else blank.copy()
                cv2.putText(rgb_s,   'RGB Feed',  (10,30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255,255,255), 2)
                cv2.putText(depth_s, 'Depth Map', (10,30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255,255,255), 2)
                top = np.hstack([rgb_s, depth_s])

            # Bottom panel: trajectory
            traj_img = self._draw_trajectory(W=500, H=340)
            bottom   = np.zeros((340, W*2, 3), np.uint8)
            offset   = (W*2 - 500) // 2
            bottom[:, offset:offset+500] = traj_img

            # FPS counter
            now = time.time()
            self._display_times.append(now)
            self._display_times = [t for t in self._display_times
                                   if now - t < 2.0]
            fps = len(self._display_times) / 2.0

            # Title bar
            bar = np.zeros((30, W*2, 3), np.uint8)
            cv2.putText(bar,
                f'Pseudo RGB-D SLAM  |  RGB+ORB  |  Depth(metric)  |  Trajectory  '
                f'|  disp={fps:.1f}fps',
                (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (160,220,255), 1)

            # Stack and display
            combined = np.vstack([bar, top, bottom])
            combined = cv2.resize(combined, (1280, 680))

            cv2.imshow('Pseudo RGB-D SLAM', combined)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord('q'), ord('Q'), 27):
                self.get_logger().info('Quit.')
                rclpy.shutdown()
                break

            # Maintain target display rate
            elapsed = time.time() - t0
            sleep_t = target_period - elapsed
            if sleep_t > 0:
                time.sleep(sleep_t)

        cv2.destroyAllWindows()

    def destroy_node(self):
        self._stop_event.set()
        self._display_thread.join(timeout=2.0)
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = Visualizer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
