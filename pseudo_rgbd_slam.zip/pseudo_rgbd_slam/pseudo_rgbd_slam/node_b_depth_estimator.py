#!/usr/bin/env python3
"""
Node B: Neural Depth Estimator — FAST VERSION
===============================================
Key optimizations:
  1. BACKGROUND THREAD: depth inference runs in a separate thread.
     The ROS subscriber callback returns immediately (never blocks).
     This prevents the entire ROS executor from blocking.

  2. FRAME DROPPING: if a new frame arrives before the previous
     inference is done, the old frame is dropped. This keeps
     latency low (always process the LATEST frame, not a stale one).

  3. HALF PRECISION (FP16): 2x faster on any NVIDIA GPU with minimal
     quality loss. Enabled by default.

  4. INPUT RESIZING: resize to 384px (instead of 518px) for 2x speedup
     with small quality loss. Configurable via input_size parameter.

  5. TORCH.COMPILE (optional): PyTorch 2.0 graph compilation for
     additional 10-30% speedup.

Architecture of the async pipeline:
  ROS callback → puts frame in queue (non-blocking)
  Background thread → reads queue → runs inference → publishes result
  
  Queue size = 1 (drop old frames = always process latest)
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo
from cv_bridge import CvBridge

import cv2
import numpy as np
import torch
import time
import threading
import queue
import inspect


class DepthEstimator(Node):
    def __init__(self):
        super().__init__('node_b_depth_estimator')

        # ── Parameters ────────────────────────────────────────────────
        self.declare_parameter('model_name',     'unidepth-v2-vits14')
        self.declare_parameter('device',         'auto')
        self.declare_parameter('max_depth',      10.0)
        self.declare_parameter('half_precision', True)   # FP16 — 2x faster
        self.declare_parameter('input_size',     384)    # Smaller = faster (orig 518)
        self.declare_parameter('use_compile',    False)  # torch.compile (PyTorch 2.0)

        model_name       = self.get_parameter('model_name').value
        device_str       = self.get_parameter('device').value
        self.max_depth   = self.get_parameter('max_depth').value
        self.half_prec   = self.get_parameter('half_precision').value
        self.input_size  = self.get_parameter('input_size').value
        self.use_compile = self.get_parameter('use_compile').value

        # ── Device ────────────────────────────────────────────────────
        if device_str == 'auto':
            self.device = torch.device(
                'cuda' if torch.cuda.is_available() else 'cpu')
        else:
            self.device = torch.device(device_str)

        if self.device.type == 'cpu':
            self.half_prec = False  # FP16 not supported on CPU
            self.get_logger().warn('CPU mode — FP16 disabled, expect slow inference')

        if torch.cuda.is_available():
            gpu = torch.cuda.get_device_name(0)
            mem = torch.cuda.get_device_properties(0).total_memory / 1e9
            self.get_logger().info(f'GPU: {gpu} ({mem:.1f}GB)')

        self.get_logger().info(
            f'Device={self.device} | FP16={self.half_prec} | '
            f'input_size={self.input_size}')

        # ── Load model ────────────────────────────────────────────────
        self.model      = None
        self.model_type = 'none'
        self._load_model(model_name)

        # ── Async inference queue ─────────────────────────────────────
        # Queue size=1: always process latest frame, drop stale ones
        self._infer_queue = queue.Queue(maxsize=1)
        self._result_lock = threading.Lock()
        self._last_depth  = None
        self._last_stamp  = None
        self._stop_event  = threading.Event()

        # Start background inference thread
        self._infer_thread = threading.Thread(
            target=self._inference_worker, daemon=True)
        self._infer_thread.start()

        # ── ROS2 setup ────────────────────────────────────────────────
        self.bridge = CvBridge()

        # Subscribe to RGB and CameraInfo SEPARATELY (not synchronized)
        # This avoids the synchronization delay and processes every frame
        self._latest_info = None
        self._info_lock   = threading.Lock()

        self.create_subscription(
            CameraInfo, '/rgb/camera_info', self._info_cb, 10)
        self.create_subscription(
            Image, '/rgb/image_raw', self._rgb_cb, 10)

        self.pub_depth = self.create_publisher(Image, '/depth/image_raw', 5)
        self.pub_viz   = self.create_publisher(Image, '/depth/colormap',  5)

        # Stats
        self.frame_count   = 0
        self.total_time_ms = 0.0
        self.get_logger().info('Node B ready — async inference thread started.')

    # ── Model Loading ─────────────────────────────────────────────────
    def _load_model(self, model_name: str):
        try:
            from unidepth.models import UniDepthV2
            self.get_logger().info(f'Loading UniDepthV2 ({model_name})...')
            self.model = UniDepthV2.from_pretrained(f'lpiccinelli/{model_name}')
            self.model = self.model.to(self.device)

            if self.half_prec:
                self.model = self.model.half()

            self.model.eval()

            # Optional: torch.compile for extra speedup (PyTorch 2.0+)
            if self.use_compile:
                try:
                    self.model = torch.compile(self.model, mode='reduce-overhead')
                    self.get_logger().info('torch.compile enabled')
                except Exception as e:
                    self.get_logger().warn(f'torch.compile failed: {e}')

            self.model_type = 'unidepth'

            # Warmup run (first inference is always slow due to JIT)
            self.get_logger().info('Running warmup inference...')
            dummy = torch.zeros(
                1, 3, self.input_size, self.input_size,
                dtype=torch.float16 if self.half_prec else torch.float32
            ).to(self.device)
            with torch.no_grad():
                try:
                    self.model.infer(dummy)
                except Exception:
                    pass
            self.get_logger().info('UniDepthV2 loaded and warmed up!')
            return
        except Exception as e:
            self.get_logger().warn(f'UniDepth failed: {e}')

        # MiDaS fallback
        try:
            self.get_logger().info('Loading MiDaS-Small fallback...')
            self.model = torch.hub.load(
                'intel-isl/MiDaS', 'MiDaS_small', trust_repo=True)
            self.model = self.model.to(self.device).eval()
            transforms = torch.hub.load(
                'intel-isl/MiDaS', 'transforms', trust_repo=True)
            self.midas_transform = transforms.small_transform
            self.model_type = 'midas'
            self.get_logger().info('MiDaS-Small loaded.')
        except Exception as e:
            self.get_logger().error(f'All models failed: {e}')

    # ── ROS Callbacks (NON-BLOCKING) ──────────────────────────────────
    def _info_cb(self, msg: CameraInfo):
        """Store latest camera info — never blocks."""
        with self._info_lock:
            self._latest_info = msg

    def _rgb_cb(self, msg: Image):
        """
        Called every time a new RGB frame arrives.
        Just puts it in the queue — returns immediately.
        If queue is full (inference still running), drops old frame.
        """
        try:
            rgb_cv = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f'cv_bridge: {e}')
            return

        with self._info_lock:
            info = self._latest_info

        # Build frame package
        frame_pkg = {
            'rgb':   rgb_cv,
            'stamp': msg.header.stamp,
            'fx':    info.k[0] if info else 517.3,
            'fy':    info.k[4] if info else 516.5,
            'cx':    info.k[2] if info else 318.6,
            'cy':    info.k[5] if info else 255.3,
        }

        # Non-blocking put: if queue full, remove old frame and add new
        try:
            self._infer_queue.put_nowait(frame_pkg)
        except queue.Full:
            try:
                self._infer_queue.get_nowait()  # discard old
            except queue.Empty:
                pass
            try:
                self._infer_queue.put_nowait(frame_pkg)
            except queue.Full:
                pass

    # ── Background Inference Thread ────────────────────────────────────
    def _inference_worker(self):
        """
        Runs in a background thread.
        Reads frames from queue, runs depth inference, publishes results.
        This is the ONLY place where slow inference happens.
        """
        self.get_logger().info('Inference worker thread started.')

        while not self._stop_event.is_set():
            try:
                pkg = self._infer_queue.get(timeout=1.0)
            except queue.Empty:
                continue

            rgb_cv = pkg['rgb']
            stamp  = pkg['stamp']
            fx, fy, cx, cy = pkg['fx'], pkg['fy'], pkg['cx'], pkg['cy']

            t0 = time.time()

            if self.model_type == 'unidepth':
                depth = self._run_unidepth(rgb_cv, fx, fy, cx, cy)
            elif self.model_type == 'midas':
                depth = self._run_midas(rgb_cv)
            else:
                depth = np.zeros(rgb_cv.shape[:2], dtype=np.float32)

            elapsed_ms = (time.time() - t0) * 1000

            # Publish from the worker thread (rclpy is thread-safe for publishing)
            self._publish_depth(depth, stamp)

            self.frame_count   += 1
            self.total_time_ms += elapsed_ms

            if self.frame_count % 10 == 0:
                avg = self.total_time_ms / self.frame_count
                self.get_logger().info(
                    f'[Node B] frame={self.frame_count} | '
                    f'{elapsed_ms:.0f}ms | avg={avg:.0f}ms | '
                    f'depth=[{depth.min():.2f},{depth.max():.2f}]m')

    # ── Inference ─────────────────────────────────────────────────────
    @torch.no_grad()
    def _run_unidepth(self, rgb_np, fx, fy, cx, cy):
        """
        UniDepthV2 inference with input resizing for speed.
        Smaller input_size = faster inference, slightly lower quality.
        """
        h_orig, w_orig = rgb_np.shape[:2]

        # Resize for faster inference
        if self.input_size and self.input_size != max(h_orig, w_orig):
            scale = self.input_size / max(h_orig, w_orig)
            new_w = int(w_orig * scale)
            new_h = int(h_orig * scale)
            rgb_small = cv2.resize(
                rgb_np, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            # Scale intrinsics accordingly
            fx_s = fx * scale; fy_s = fy * scale
            cx_s = cx * scale; cy_s = cy * scale
        else:
            rgb_small = rgb_np
            fx_s, fy_s, cx_s, cy_s = fx, fy, cx, cy

        # BGR → RGB, HWC → CHW, normalize
        rgb_rgb = cv2.cvtColor(rgb_small, cv2.COLOR_BGR2RGB)
        dtype   = torch.float16 if self.half_prec else torch.float32
        rgb_t   = (torch.from_numpy(rgb_rgb)
                   .permute(2, 0, 1)
                   .to(dtype=dtype, device=self.device)
                   / 255.0
                   ).unsqueeze(0)

        K = torch.tensor(
            [[fx_s, 0., cx_s], [0., fy_s, cy_s], [0., 0., 1.]],
            dtype=dtype, device=self.device).unsqueeze(0)

        try:
            from unidepth.utils.camera import Pinhole
            cam   = Pinhole(K=K)
            preds = self.model.infer(rgb_t, cam)
        except Exception:
            try:
                preds = self.model.infer(rgb_t)
            except Exception as e:
                self.get_logger().error(f'infer failed: {e}')
                return np.zeros((h_orig, w_orig), dtype=np.float32)

        depth_small = preds['depth'].squeeze().float().cpu().numpy()

        # Resize depth back to original resolution
        if depth_small.shape != (h_orig, w_orig):
            depth = cv2.resize(
                depth_small, (w_orig, h_orig),
                interpolation=cv2.INTER_LINEAR)
        else:
            depth = depth_small

        return np.clip(depth.astype(np.float32), 0.0, self.max_depth)

    @torch.no_grad()
    def _run_midas(self, rgb_np):
        rgb_rgb = cv2.cvtColor(rgb_np, cv2.COLOR_BGR2RGB)
        inp  = self.midas_transform(rgb_rgb).to(self.device)
        pred = self.model(inp)
        pred = torch.nn.functional.interpolate(
            pred.unsqueeze(1), size=rgb_np.shape[:2],
            mode='bicubic', align_corners=False
        ).squeeze().cpu().numpy()
        pred = pred - pred.min()
        if pred.max() > 1e-6:
            pred = pred / pred.max() * self.max_depth
        return pred.astype(np.float32)

    # ── Publish ────────────────────────────────────────────────────────
    def _publish_depth(self, depth: np.ndarray, stamp):
        # Raw depth (32FC1 = float32, meters)
        dm = self.bridge.cv2_to_imgmsg(depth, encoding='32FC1')
        dm.header.stamp    = stamp
        dm.header.frame_id = 'camera'
        self.pub_depth.publish(dm)

        # Colorized visualization
        d_u8 = (depth / self.max_depth * 255).clip(0, 255).astype(np.uint8)
        viz  = cv2.applyColorMap(d_u8, cv2.COLORMAP_INFERNO)
        vm   = self.bridge.cv2_to_imgmsg(viz, encoding='bgr8')
        vm.header.stamp    = stamp
        vm.header.frame_id = 'camera'
        self.pub_viz.publish(vm)

    def destroy_node(self):
        self._stop_event.set()
        self._infer_thread.join(timeout=3.0)
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = DepthEstimator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
