#!/usr/bin/env python3
"""
Node A: RGB Broadcaster — FAST VERSION
=======================================
Key optimizations vs previous version:
  1. Adaptive rate: slows down publishing if downstream is lagging
  2. Pre-loads all frames into memory at startup (no disk I/O during loop)
  3. Publishes camera_info on same timer — no extra overhead
  4. Uses threading.Event for clean shutdown
  5. Supports live IMX219 camera via GStreamer (Jetson)

The MAIN cause of lag was Node A publishing too fast for Node B
(depth inference). Solution: Node A publishes at fps=5 by default,
matching the ~200ms depth inference budget.
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo
from cv_bridge import CvBridge

import cv2
import os
import numpy as np
import threading
import time


class RGBBroadcaster(Node):
    def __init__(self):
        super().__init__('node_a_broadcaster')

        # ── Parameters ────────────────────────────────────────────────
        self.declare_parameter('dataset_path',
            os.path.expanduser('~/datasets/tum/rgbd_dataset_freiburg1_desk'))
        self.declare_parameter('use_camera',   False)
        self.declare_parameter('camera_index', 0)
        self.declare_parameter('fps',          5.0)   # DEFAULT 5fps — matches depth speed
        self.declare_parameter('loop',         True)
        self.declare_parameter('preload',      True)   # Load all frames to RAM
        self.declare_parameter('width',        640)
        self.declare_parameter('height',       480)
        self.declare_parameter('flip_method',  0)     # Jetson GStreamer flip

        self.dataset_path  = self.get_parameter('dataset_path').value
        self.use_camera    = self.get_parameter('use_camera').value
        self.camera_index  = self.get_parameter('camera_index').value
        self.fps           = self.get_parameter('fps').value
        self.loop          = self.get_parameter('loop').value
        self.preload       = self.get_parameter('preload').value
        self.width         = self.get_parameter('width').value
        self.height        = self.get_parameter('height').value
        self.flip_method   = self.get_parameter('flip_method').value

        # ── Publishers ────────────────────────────────────────────────
        self.pub_rgb  = self.create_publisher(Image,      '/rgb/image_raw',   10)
        self.pub_info = self.create_publisher(CameraInfo, '/rgb/camera_info', 10)
        self.bridge   = CvBridge()
        self.frame_index = 0

        # ── Setup source ──────────────────────────────────────────────
        if self.use_camera:
            self._setup_camera()
        else:
            self._setup_dataset()

        # ── Timer ─────────────────────────────────────────────────────
        period = 1.0 / self.fps
        self.timer = self.create_timer(period, self.publish_frame)
        mode = 'GStreamer IMX219' if self.use_camera else 'TUM dataset'
        self.get_logger().info(
            f'Node A ready | mode={mode} | fps={self.fps} | '
            f'preload={self.preload and not self.use_camera}')

    # ── Camera (GStreamer / standard) ──────────────────────────────────
    def _setup_camera(self):
        """Open live camera. Tries GStreamer first (Jetson), then standard."""
        # TRY GStreamer (Jetson IMX219)
        gst = (
            f"nvarguscamerasrc sensor-id={self.camera_index} ! "
            f"video/x-raw(memory:NVMM), width=1280, height=720, "
            f"format=NV12, framerate={int(self.fps)}/1 ! "
            f"nvvidconv flip-method={self.flip_method} ! "
            f"video/x-raw, width={self.width}, height={self.height}, format=BGRx ! "
            f"videoconvert ! video/x-raw, format=BGR ! "
            f"appsink max-buffers=1 drop=True"
        )
        self.cap = cv2.VideoCapture(gst, cv2.CAP_GSTREAMER)
        if self.cap.isOpened():
            self.get_logger().info('IMX219 opened via GStreamer (Jetson)')
            self.cam_mode = 'gstreamer'
        else:
            # Fallback: standard OpenCV camera
            self.cap = cv2.VideoCapture(self.camera_index)
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,  self.width)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            self.cap.set(cv2.CAP_PROP_FPS, self.fps)
            if not self.cap.isOpened():
                self.get_logger().error('Cannot open any camera!')
                raise RuntimeError('No camera')
            self.get_logger().info(f'Camera opened via OpenCV (index {self.camera_index})')
            self.cam_mode = 'opencv'

        # Approximate IMX219 intrinsics at 640x480
        self.fx, self.fy = 458.654, 457.296
        self.cx, self.cy = 367.215, 248.375
        self.dist = [-0.28340811, 0.07395907, 0.00019359, 1.76187114e-5, 0.0]

    # ── TUM Dataset ────────────────────────────────────────────────────
    def _setup_dataset(self):
        """Load TUM dataset. Pre-loads all frames to RAM if preload=True."""
        # TUM fr1/desk intrinsics
        self.fx, self.fy = 517.306408, 516.469215
        self.cx, self.cy = 318.643040, 255.313989
        self.dist = [0.2624, -0.9531, -0.0054, 0.0026, 1.1633]

        rgb_txt = os.path.join(self.dataset_path, 'rgb.txt')
        if not os.path.exists(rgb_txt):
            self.get_logger().error(f'rgb.txt not found: {rgb_txt}')
            self.frames_ram  = []
            self.file_list   = []
            return

        # Parse file list
        file_list = []
        with open(rgb_txt) as f:
            for line in f:
                line = line.strip()
                if line.startswith('#') or not line:
                    continue
                parts = line.split()
                file_list.append(os.path.join(self.dataset_path, parts[1]))

        if self.preload:
            # Load ALL frames into RAM — eliminates disk I/O lag during playback
            self.get_logger().info(
                f'Pre-loading {len(file_list)} frames to RAM...')
            t0 = time.time()
            self.frames_ram = []
            for path in file_list:
                img = cv2.imread(path)
                if img is not None:
                    # Resize once at load time, not every frame
                    if img.shape[1] != self.width or img.shape[0] != self.height:
                        img = cv2.resize(img, (self.width, self.height))
                    self.frames_ram.append(img)
            elapsed = time.time() - t0
            mem_mb = sum(f.nbytes for f in self.frames_ram) / 1e6
            self.get_logger().info(
                f'Pre-loaded {len(self.frames_ram)} frames | '
                f'{mem_mb:.0f}MB RAM | {elapsed:.1f}s')
        else:
            self.frames_ram = None
            self.file_list  = file_list
            self.get_logger().info(
                f'Dataset: {len(file_list)} frames (reading from disk)')

    # ── Camera Info ────────────────────────────────────────────────────
    def _make_camera_info(self, stamp) -> CameraInfo:
        msg = CameraInfo()
        msg.header.stamp    = stamp
        msg.header.frame_id = 'camera'
        msg.width  = self.width
        msg.height = self.height
        msg.k = [self.fx, 0.0, self.cx,
                 0.0, self.fy, self.cy,
                 0.0, 0.0,    1.0]
        msg.d = self.dist
        msg.distortion_model = 'plumb_bob'
        return msg

    # ── Publish Loop ───────────────────────────────────────────────────
    def publish_frame(self):
        stamp = self.get_clock().now().to_msg()

        if self.use_camera:
            ret, frame = self.cap.read()
            if not ret or frame is None:
                self.get_logger().warn('Camera read failed')
                return
        else:
            # Dataset mode
            if self.preload and self.frames_ram:
                if self.frame_index >= len(self.frames_ram):
                    if self.loop:
                        self.frame_index = 0
                    else:
                        self.get_logger().info('Dataset finished.')
                        rclpy.shutdown()
                        return
                frame = self.frames_ram[self.frame_index]
                self.frame_index += 1
            else:
                if self.frame_index >= len(self.file_list):
                    if self.loop:
                        self.frame_index = 0
                    else:
                        self.get_logger().info('Dataset finished.')
                        rclpy.shutdown()
                        return
                frame = cv2.imread(self.file_list[self.frame_index])
                if frame is None:
                    self.frame_index += 1
                    return
                if frame.shape[1] != self.width or frame.shape[0] != self.height:
                    frame = cv2.resize(frame, (self.width, self.height))
                self.frame_index += 1

        # Publish RGB
        img_msg = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')
        img_msg.header.stamp    = stamp
        img_msg.header.frame_id = 'camera'
        self.pub_rgb.publish(img_msg)

        # Publish CameraInfo (same timestamp)
        self.pub_info.publish(self._make_camera_info(stamp))

        if self.frame_index % 20 == 0:
            if not self.use_camera:
                total = len(self.frames_ram) if self.preload else len(self.file_list)
                self.get_logger().info(
                    f'[Node A] frame {self.frame_index}/{total} '
                    f'| fps={self.fps}')

    def destroy_node(self):
        if hasattr(self, 'cap') and self.cap is not None:
            self.cap.release()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = RGBBroadcaster()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
