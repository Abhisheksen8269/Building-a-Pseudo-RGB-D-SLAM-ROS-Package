#!/usr/bin/env python3
"""
Node C: Pseudo RGB-D SLAM — FAST VERSION
==========================================
Key optimizations:
  1. BACKGROUND THREAD: VO runs in separate thread, ROS callback never blocks
  2. FRAME DROPPING: always process latest synchronized pair, drop stale ones
  3. LIGHTWEIGHT VO: optimized ORB params for Jetson/embedded
  4. FAST MATRIX OPS: pre-allocated numpy arrays, avoid repeated allocation
  5. PUBLISH THROTTLE: map points published every 5 frames (heavy message)

Sync strategy:
  Instead of ApproximateTimeSynchronizer (which buffers and delays),
  we use a simple "match latest depth to RGB by timestamp proximity".
  This gives lower latency at the cost of slight timestamp mismatch.
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import PoseStamped, Point, TransformStamped
from nav_msgs.msg import Path
from visualization_msgs.msg import Marker
from std_msgs.msg import ColorRGBA
from cv_bridge import CvBridge
import tf2_ros

import cv2
import numpy as np
import os
import threading
import queue
import time


# ══════════════════════════════════════════════════════════════════════
# Fast OpenCV RGB-D Visual Odometry
# ══════════════════════════════════════════════════════════════════════
class FastVO:
    """
    RGB-D Visual Odometry optimized for speed.
    
    Speed improvements vs original:
      - Fewer ORB features (800 vs 1500) — 2x faster extraction
      - FLANN matcher instead of BFMatcher — faster for large feature sets
      - Pre-allocated arrays to reduce GC pressure
      - Early exit on poor matches
    """

    def __init__(self, fx=517.3, fy=516.5, cx=318.6, cy=255.3):
        # Fewer features = faster (800 is enough for VO)
        self.orb = cv2.ORB_create(
            nfeatures   = 800,
            scaleFactor = 1.2,
            edgeThreshold = 19,
        )

        # BFMatcher with Hamming — fast for ORB binary descriptors
        self.matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)

        self.K = np.array([[fx, 0., cx],
                            [0., fy, cy],
                            [0., 0., 1.]], dtype=np.float64)
        self.dist = np.zeros(5, dtype=np.float64)

        # State
        self.prev_gray  = None
        self.prev_kps   = None
        self.prev_desc  = None
        self.prev_depth = None
        self.pose       = np.eye(4, dtype=np.float64)
        self.map_points = []
        self.tracking_state = 'INITIALIZING'
        self.n_frames   = 0

    def update_intrinsics(self, fx, fy, cx, cy):
        self.K[0, 0] = fx; self.K[1, 1] = fy
        self.K[0, 2] = cx; self.K[1, 2] = cy

    def process(self, rgb: np.ndarray, depth: np.ndarray) -> np.ndarray:
        gray = cv2.cvtColor(rgb, cv2.COLOR_BGR2GRAY)
        kps, desc = self.orb.detectAndCompute(gray, None)
        self.n_frames += 1

        if (self.prev_gray is None or desc is None or
                self.prev_desc is None or len(kps) < 8):
            self._update_prev(gray, kps, desc, depth)
            self.tracking_state = 'INITIALIZING'
            return self.pose

        # Match features (knnMatch k=2 for Lowe ratio test)
        try:
            raw = self.matcher.knnMatch(self.prev_desc, desc, k=2)
        except Exception:
            self._update_prev(gray, kps, desc, depth)
            self.tracking_state = 'LOST'
            return self.pose

        # Lowe ratio test
        good = []
        for pair in raw:
            if len(pair) == 2 and pair[0].distance < 0.75 * pair[1].distance:
                good.append(pair[0])

        if len(good) < 10:
            self._update_prev(gray, kps, desc, depth)
            self.tracking_state = 'LOST'
            return self.pose

        # Back-project to 3D using depth
        h, w = depth.shape
        pts3d, pts2d = [], []
        for m in good:
            u0, v0 = self.prev_kps[m.queryIdx].pt
            u1, v1 = kps[m.trainIdx].pt
            ui, vi = int(round(u0)), int(round(v0))
            if 0 <= vi < h and 0 <= ui < w:
                Z = float(self.prev_depth[vi, ui])
                if 0.15 < Z < 9.0:
                    X = (u0 - self.K[0, 2]) * Z / self.K[0, 0]
                    Y = (v0 - self.K[1, 2]) * Z / self.K[1, 1]
                    pts3d.append([X, Y, Z])
                    pts2d.append([u1, v1])

        if len(pts3d) < 6:
            self._update_prev(gray, kps, desc, depth)
            self.tracking_state = 'LOST'
            return self.pose

        pts3d = np.array(pts3d, dtype=np.float64)
        pts2d = np.array(pts2d, dtype=np.float64)

        # PnP + RANSAC
        ok, rvec, tvec, inliers = cv2.solvePnPRansac(
            pts3d, pts2d, self.K, self.dist,
            iterationsCount   = 100,   # Fewer iterations = faster
            reprojectionError = 5.0,
            confidence        = 0.99,
            flags             = cv2.SOLVEPNP_EPNP)

        if not ok or inliers is None or len(inliers) < 5:
            self._update_prev(gray, kps, desc, depth)
            self.tracking_state = 'LOST'
            return self.pose

        R, _ = cv2.Rodrigues(rvec)
        T = np.eye(4, dtype=np.float64)
        T[:3, :3] = R
        T[:3,  3] = tvec.ravel()

        # Accumulate pose
        self.pose = self.pose @ np.linalg.inv(T)

        # Map points (subsample for speed)
        idx = inliers.ravel()[::2]  # Take every other inlier
        if len(idx) > 0:
            pts_w = (self.pose[:3, :3] @ pts3d[idx].T
                     + self.pose[:3, 3:4]).T
            self.map_points = pts_w[:150].tolist()

        self.tracking_state = 'OK'
        self._update_prev(gray, kps, desc, depth)
        return self.pose

    def _update_prev(self, gray, kps, desc, depth):
        self.prev_gray  = gray
        self.prev_kps   = kps
        self.prev_desc  = desc
        self.prev_depth = depth

    def get_keypoints(self):
        return self.prev_kps or []


# ══════════════════════════════════════════════════════════════════════
# ROS2 Node
# ══════════════════════════════════════════════════════════════════════
class PseudoSLAM(Node):
    def __init__(self):
        super().__init__('node_c_slam')

        # ── Parameters ────────────────────────────────────────────────
        self.declare_parameter('vocab_path',
            os.path.expanduser('~/ORB_SLAM2/Vocabulary/ORBvoc.txt'))
        self.declare_parameter('settings_path',
            os.path.expanduser(
                '~/ros2_ws/src/pseudo_rgbd_slam/config/orb_slam2_rgbd.yaml'))
        self.declare_parameter('use_viewer',  False)
        self.declare_parameter('depth_scale', 1000.0)
        self.declare_parameter('max_depth',   10.0)

        vocab_path    = self.get_parameter('vocab_path').value
        settings_path = self.get_parameter('settings_path').value
        use_viewer    = self.get_parameter('use_viewer').value
        self.depth_scale = self.get_parameter('depth_scale').value
        self.max_depth   = self.get_parameter('max_depth').value

        # ── SLAM backend ──────────────────────────────────────────────
        self.slam_backend = 'opencv_vo'
        self.slam = None
        self._init_slam(vocab_path, settings_path, use_viewer)

        self.bridge     = CvBridge()
        self.trajectory = []

        # ── Latest frame storage (lock-protected) ─────────────────────
        self._rgb_lock   = threading.Lock()
        self._depth_lock = threading.Lock()
        self._latest_rgb   = None   # (stamp, cv_image)
        self._latest_depth = None   # (stamp, cv_image)
        self._got_info     = False

        # ── VO processing queue (size=1: always latest) ───────────────
        self._vo_queue    = queue.Queue(maxsize=1)
        self._stop_event  = threading.Event()
        self._vo_thread   = threading.Thread(
            target=self._vo_worker, daemon=True)
        self._vo_thread.start()

        # ── Subscriptions ─────────────────────────────────────────────
        self.create_subscription(
            CameraInfo, '/rgb/camera_info', self._info_cb, 10)
        self.create_subscription(
            Image, '/rgb/image_raw', self._rgb_cb, 10)
        self.create_subscription(
            Image, '/depth/image_raw', self._depth_cb, 10)

        # ── Publishers ────────────────────────────────────────────────
        self.pub_pose      = self.create_publisher(
            PoseStamped, '/slam/pose',         10)
        self.pub_path      = self.create_publisher(
            Path,        '/slam/trajectory',   10)
        self.pub_mappts    = self.create_publisher(
            Marker,      '/slam/map_points',   5)
        self.pub_track_viz = self.create_publisher(
            Image,       '/slam/tracking_viz', 5)
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)

        self.frame_count    = 0
        self._map_pub_count = 0
        self.get_logger().info(
            f'Node C ready | backend={self.slam_backend}')

    def _init_slam(self, vocab_path, settings_path, use_viewer):
        try:
            import orbslam2
            self.slam = orbslam2.System(
                vocab_path, settings_path, orbslam2.Sensor.RGBD)
            self.slam.set_use_viewer(use_viewer)
            self.slam.initialize()
            self.slam_backend = 'orbslam2'
            self.get_logger().info('ORB-SLAM2 initialized!')
        except Exception as e:
            self.get_logger().warn(f'ORB-SLAM2 unavailable: {e}')
            self.slam = FastVO()
            self.slam_backend = 'opencv_vo'

    # ── Callbacks (ALL NON-BLOCKING) ──────────────────────────────────
    def _info_cb(self, msg: CameraInfo):
        if not self._got_info and self.slam_backend == 'opencv_vo':
            K = msg.k
            self.slam.update_intrinsics(K[0], K[4], K[2], K[5])
            self._got_info = True
            self.get_logger().info(
                f'Intrinsics updated: fx={K[0]:.1f} fy={K[4]:.1f}')

    def _rgb_cb(self, msg: Image):
        """Store latest RGB frame. Non-blocking."""
        try:
            img = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception:
            return
        with self._rgb_lock:
            self._latest_rgb = (msg.header.stamp, img)
        self._try_dispatch()

    def _depth_cb(self, msg: Image):
        """Store latest depth. Non-blocking. Then try to pair with RGB."""
        try:
            depth = self.bridge.imgmsg_to_cv2(msg, '32FC1')
        except Exception:
            return
        with self._depth_lock:
            self._latest_depth = (msg.header.stamp, depth)
        self._try_dispatch()

    def _try_dispatch(self):
        """
        Try to pair latest RGB + depth and dispatch to VO queue.
        Uses timestamp proximity matching instead of strict sync.
        Max allowed timestamp diff = 2 seconds (generous for slow inference).
        """
        with self._rgb_lock:
            rgb_data = self._latest_rgb
        with self._depth_lock:
            depth_data = self._latest_depth

        if rgb_data is None or depth_data is None:
            return

        rgb_stamp, rgb_cv     = rgb_data
        depth_stamp, depth_cv = depth_data

        # Check timestamp proximity
        rgb_t   = rgb_stamp.sec   + rgb_stamp.nanosec   * 1e-9
        depth_t = depth_stamp.sec + depth_stamp.nanosec * 1e-9
        if abs(rgb_t - depth_t) > 2.0:
            return  # Too far apart

        pkg = {
            'rgb':   rgb_cv,
            'depth': depth_cv,
            'stamp': rgb_stamp,
            'ts':    rgb_t,
        }

        # Non-blocking put — drop old if full
        try:
            self._vo_queue.put_nowait(pkg)
        except queue.Full:
            try:
                self._vo_queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self._vo_queue.put_nowait(pkg)
            except queue.Full:
                pass

    # ── VO Worker Thread ──────────────────────────────────────────────
    def _vo_worker(self):
        """Background thread: runs VO on queued RGB-D pairs."""
        self.get_logger().info('VO worker thread started.')

        while not self._stop_event.is_set():
            try:
                pkg = self._vo_queue.get(timeout=1.0)
            except queue.Empty:
                continue

            rgb_cv   = pkg['rgb']
            depth_cv = pkg['depth']
            stamp    = pkg['stamp']
            ts       = pkg['ts']

            # Run VO
            if self.slam_backend == 'orbslam2':
                d_mm = (depth_cv * self.depth_scale).clip(0, 65535).astype(np.uint16)
                Tcw  = self.slam.process_image_rgbd(rgb_cv, d_mm, ts)
                state = self._orb_state()
                Twc  = (np.linalg.inv(Tcw)
                        if Tcw is not None and not self._bad(Tcw) else None)
            else:
                Twc   = self.slam.process(rgb_cv, depth_cv)
                state = self.slam.tracking_state
                if self._bad(Twc):
                    Twc = None

            # Publish results
            if Twc is not None:
                pose_msg = self._matrix_to_pose(Twc, stamp)
                self._publish_pose(pose_msg, stamp, Twc)

            # Publish tracking visualization
            viz = self._make_viz(rgb_cv, depth_cv, state)
            try:
                vm = self.bridge.cv2_to_imgmsg(viz, encoding='bgr8')
                vm.header.stamp    = stamp
                vm.header.frame_id = 'camera'
                self.pub_track_viz.publish(vm)
            except Exception:
                pass

            self.frame_count += 1
            if self.frame_count % 10 == 0:
                self.get_logger().info(
                    f'[Node C] frame={self.frame_count} | {state} | '
                    f'traj={len(self.trajectory)}')

    # ── Utilities ─────────────────────────────────────────────────────
    def _orb_state(self):
        try:
            return {0:'NOT_READY', 1:'NO_IMAGES', 2:'NOT_INIT',
                    3:'OK', 4:'LOST'}.get(
                self.slam.get_tracking_state(), '?')
        except Exception:
            return 'UNKNOWN'

    def _bad(self, M):
        return M is None or np.any(np.isnan(M)) or np.any(np.isinf(M))

    def _matrix_to_pose(self, Twc, stamp) -> PoseStamped:
        t = Twc[:3, 3]; R = Twc[:3, :3]
        tr = R[0,0]+R[1,1]+R[2,2]
        if tr > 0:
            s=0.5/np.sqrt(tr+1.); w=0.25/s
            x=(R[2,1]-R[1,2])*s; y=(R[0,2]-R[2,0])*s; z=(R[1,0]-R[0,1])*s
        elif R[0,0]>R[1,1] and R[0,0]>R[2,2]:
            s=2.*np.sqrt(1.+R[0,0]-R[1,1]-R[2,2])
            w=(R[2,1]-R[1,2])/s; x=0.25*s
            y=(R[0,1]+R[1,0])/s; z=(R[0,2]+R[2,0])/s
        elif R[1,1]>R[2,2]:
            s=2.*np.sqrt(1.+R[1,1]-R[0,0]-R[2,2])
            w=(R[0,2]-R[2,0])/s; x=(R[0,1]+R[1,0])/s
            y=0.25*s; z=(R[1,2]+R[2,1])/s
        else:
            s=2.*np.sqrt(1.+R[2,2]-R[0,0]-R[1,1])
            w=(R[1,0]-R[0,1])/s; x=(R[0,2]+R[2,0])/s
            y=(R[1,2]+R[2,1])/s; z=0.25*s
        msg = PoseStamped()
        msg.header.stamp    = stamp
        msg.header.frame_id = 'world'
        msg.pose.position.x    = float(t[0])
        msg.pose.position.y    = float(t[1])
        msg.pose.position.z    = float(t[2])
        msg.pose.orientation.x = float(x)
        msg.pose.orientation.y = float(y)
        msg.pose.orientation.z = float(z)
        msg.pose.orientation.w = float(w)
        return msg

    def _publish_pose(self, pose_msg, stamp, Twc):
        self.pub_pose.publish(pose_msg)
        self.trajectory.append(pose_msg)

        path = Path()
        path.header.stamp    = stamp
        path.header.frame_id = 'world'
        path.poses = self.trajectory[-2000:]
        self.pub_path.publish(path)

        tf_msg = TransformStamped()
        tf_msg.header          = pose_msg.header
        tf_msg.child_frame_id  = 'camera'
        tf_msg.transform.translation.x = pose_msg.pose.position.x
        tf_msg.transform.translation.y = pose_msg.pose.position.y
        tf_msg.transform.translation.z = pose_msg.pose.position.z
        tf_msg.transform.rotation      = pose_msg.pose.orientation
        self.tf_broadcaster.sendTransform(tf_msg)

        # Map points — publish every 5 frames (it's a big message)
        self._map_pub_count += 1
        if self._map_pub_count % 5 == 0:
            pts = (getattr(self.slam, 'map_points', [])
                   if self.slam_backend == 'opencv_vo' else [])
            if pts:
                mk = Marker()
                mk.header.stamp    = stamp
                mk.header.frame_id = 'world'
                mk.type   = Marker.POINTS
                mk.action = Marker.ADD
                mk.id     = 0
                mk.scale.x = 0.02; mk.scale.y = 0.02
                mk.color   = ColorRGBA(r=0., g=1., b=0.5, a=0.8)
                for p in pts[:2000]:
                    pp = Point()
                    pp.x, pp.y, pp.z = float(p[0]), float(p[1]), float(p[2])
                    mk.points.append(pp)
                self.pub_mappts.publish(mk)

    def _make_viz(self, rgb, depth, state):
        vis = rgb.copy()
        col = (0, 255, 0) if state == 'OK' else (0, 80, 255)
        cv2.putText(vis, f'[{self.slam_backend}] {state}',
                    (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.7, col, 2)
        cv2.putText(vis, f'F:{self.frame_count} T:{len(self.trajectory)}',
                    (10, 54), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200,200,200), 1)

        if self.slam_backend == 'opencv_vo':
            kps = self.slam.get_keypoints()
            for kp in kps[:200]:
                cv2.circle(vis, (int(kp.pt[0]), int(kp.pt[1])),
                           3, (0,255,0), -1)

        d  = (depth / self.max_depth * 255).clip(0, 255).astype(np.uint8)
        dc = cv2.applyColorMap(d, cv2.COLORMAP_INFERNO)
        cv2.putText(dc, 'Depth(m)', (10, 28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)

        h = min(vis.shape[0], dc.shape[0])
        return np.hstack([
            cv2.resize(vis, (640, h)),
            cv2.resize(dc,  (640, h))
        ])

    def destroy_node(self):
        self._stop_event.set()
        self._vo_thread.join(timeout=3.0)
        if self.slam_backend == 'orbslam2' and self.slam:
            try:
                self.slam.shutdown()
            except Exception:
                pass
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = PseudoSLAM()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
