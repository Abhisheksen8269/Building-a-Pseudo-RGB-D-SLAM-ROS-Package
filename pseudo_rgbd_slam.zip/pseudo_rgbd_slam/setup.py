from setuptools import setup, find_packages
import os
from glob import glob

package_name = 'pseudo_rgbd_slam'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Abhishek',
    maintainer_email='abhishek@example.com',
    description='Pseudo RGB-D SLAM ROS2 Package',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'node_a = pseudo_rgbd_slam.node_a_broadcaster:main',
            'node_b = pseudo_rgbd_slam.node_b_depth_estimator:main',
            'node_c = pseudo_rgbd_slam.node_c_slam:main',
            'visualizer = pseudo_rgbd_slam.node_d_visualizer:main',
        ],
    },
)
